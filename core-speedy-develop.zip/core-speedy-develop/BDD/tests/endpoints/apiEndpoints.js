let self = module.exports = {

    getEndpoint: (job) => {
        let endPoint = {};
        if (job == 'local'){
            endPoint['sampleApi'] = 'http://localhost:1080/api/customerDetailsFinders/customerDetails';
            endPoint['samplePerfApi'] = 'https://reqres.in/api/users?page=2';
        } else{
            endPoint['sampleApi'] = 'http://{API_ENDPOINT}/api/customerDetailsFinders/customerDetails';
            endPoint['samplePerfApi'] = 'https://reqres.in/api/users?page=2';
        }
        return endPoint;
    }

};