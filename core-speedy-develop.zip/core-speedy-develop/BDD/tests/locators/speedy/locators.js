class homeLocators {
  constructor() {
    this.username = './/*[@id="lg"]/div[1]/div[1]/input';
    this.password = './/*[@id="lg"]/div[2]/div[1]/input';
    this.loginBtn = './/*[@id="lg"]/div[3]/button';
    this.adminToggle = '//a[@class="dropdown-toggle ng-binding" and contains(.,"Welcome ADMIN")]';
    this.settingsInToggle = '//ul[@class="dropdown-menu dropdown-menu-right"]/li/a[.="Settings"]';
    this.settingsSection = '//li[@role="presentation"]/a[.="Settings"]';
    this.jiraTab = '//div[@class="settingsTabs ng-isolate-scope"]//li/a[.="Jira"]';
    this.refreshFrequency = '//input[@placeholder="Refresh frequency"]';
    this.jiraURL = '//input[@placeholder="JIRA URL"]';
    this.submitButton = '//div/button[.="Save"]';
    this.continueButton = '//button[.="Continue"]';
    this.title = './html/head/title';
    this.dashboard = '//span[.=xxxx]';
    this.projectName_Dashboard = '//*[@id="scrum-widget-view"]//div[@class="widget-body"]';
    this.openStoryCount_Dashboard = '//div[@id="scrum-widget-view"]//div[@fit-text=".build-summary-count > span"]//div[contains(@class,"story-summary-count story-open")]/span';
    this.wipStoryCount_Dashboard = '//div[@id="scrum-widget-view"]//div[@fit-text=".build-summary-count > span"]//div[contains(@class,"story-summary-count story-wip")]/span';
    this.doneStoryCount_Dashboard = '//div[@id="scrum-widget-view"]//div[@fit-text=".build-summary-count > span"]//div[contains(@class,"story-summary-count story-done")]/span';
  }
}

module.exports = homeLocators;
