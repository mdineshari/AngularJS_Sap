const AxeBuilder = require('ob-core-accessibility-lib');

module.exports = function () {

    this.Then(/^I run "([^"]*)" accessibility standards using AXE$/, (standards) => {
        let accessibilityStandards = standards.split(",");
        return AxeBuilder.runAxeWith(browser, accessibilityStandards);
    });

    this.Then(/^I run "([^"]*)" accessibility standard using AXE$/, (standard) => {
        return AxeBuilder.runAxeWith(browser, standard);
    });
};
