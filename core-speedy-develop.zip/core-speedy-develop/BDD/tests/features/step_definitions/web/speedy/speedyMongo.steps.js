const DbClient = require('../../../../pages/speedy/validateMongoDB.page.js');
const mdbSpeedy = new DbClient();
const speedyPageData = require('../../../../files/testData/speedy/speedy.data.js');

module.exports = function () {
    this.Given(/^Validate the count of highest and medium priority stories in speedy project MongoDb$/, () => {
        mdbSpeedy.validateFeatureDataDB(speedyPageData['mdb_highMediumStoriesInProgressCount'], speedyPageData['mdb_closedBugCount']);
        browser.pause(10000);
        console.log('after connection..');
    });

    this.Then(/^Validate the count of stories with 5 point estimate in Feature Custom History for Speedy Project$/, () => {
        mdbSpeedy.validateStoryPoint_FeatureCustomHistoryTable(speedyPageData['mdb_StoryWith5PointEstimate']);
        browser.pause(10000);
        console.log('after connection..');

    });
    this.Then(/^Validate the pId from scope table for Speedy project$/, () => {
        mdbSpeedy.validatePID_ScopeTable(speedyPageData['mdb_PIDScopeTable']);
        browser.pause(10000);
        console.log('after connection..');

    });

    this.Then(/^Validate the feature_custom_history table data$/, () => {
        mdbSpeedy.validatefeatureCustomHistoryTableData(speedyPageData['mdb_PIDScopeTable']);
        browser.pause(10000);
        console.log('after connection..');

    });
};