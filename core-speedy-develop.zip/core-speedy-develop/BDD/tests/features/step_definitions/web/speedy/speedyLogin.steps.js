const cucumber = require('cucumber');
const config = require('../../../../conf/local.conf.js');
// const configVal = new config();
const speedySettingPage = require('../../../../pages/speedy/speedySettingPage.page.js');
const speedy = new speedySettingPage();
const speedyPageData = require('../../../../files/testData/speedy/speedy.data.js');

module.exports = function () {

    this.Given(/^Invoke browser with speedy url$/, () => {
        browser.pause(8000);
        speedy.openSpeedyPage();
        console.log('Browser is invoked-----');
    });
    this.When(/^Login to speedy$/, () => {
        speedy.enterLoginDetails();
    });

    this.Then(/^Validate speedy home page$/, () => {
        speedy.validateWelcomePage()
    });

//     this.Then(/^Open Dashboard (.*)$/, (dashboardName) => {
//        speedy.openDashboard(dashboardName);
//    });

//    this.Then(/^Validate the data shown in dashboard$/, () => {
//        speedy.validateDashboardData(speedyPageData['projectName_'+ envirTest], speedyPageData['openStoryCount_' +envirTest], speedyPageData['wipCount_' + envirTest], speedyPageData['doneCount_' + envirTest]);
//    });

//    this.Then(/^Open settings from admin toggle$/, () => {
//        speedy.openSettingsFromAdminToggle();
//    });

//    this.Then(/^Update Refresh frequency and JIRA url field in JIRA tab of settings section$/, () => {
//        speedy.updateRefreshFreqAndJiraURL();
//        browser.pause(130000);
//    });
};
