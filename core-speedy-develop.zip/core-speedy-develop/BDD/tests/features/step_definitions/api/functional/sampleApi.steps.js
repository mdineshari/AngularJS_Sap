const chai = require('chai');
const assertDiff = require('assert-diff');
const config = require('../../../../conf/local.conf.js').config;
// const mockApplication = require('../../../../builders/mockApplication/sampleMockRequestBuilder');
// const aut = require('../../../../builders/applicationUnderTest/sampleApiRequestBuilder');
// const expectedResults = require('../../../../files/expectedResponseFiles/'+config.app+'/sampleApiResponse').expectedResponses;
const jsonServer = require('../../../../files/mock-serverFiles/json-Server-Config');
let responseBody;
assertDiff.options.strict = true;

module.exports = function() {


    this.Given(/^I start json-server (.*)$/, (jsonFile) => {
        return jsonServer.startjsonServer(jsonFile);
    });

  this.Given(/^I set login details by specifying (.*)$/, (header) => {
      return aut.postAPI(header)
          .then((response)=>{
              responseBody = response;
              console.log("responseBody:--------", responseBody)
          });
  });

  this.Given(/^I start mock server$/, () =>{
        return mockApplication.startmockServer();
  });

    this.Given(/^I stop mock server$/, () =>{
        return mockApplication.stopmockServer();
    });

  this.Given(/^I set the expectation in the mock server by specifying (.*) and (.*) and (.*)$/, (header, queryParameter,mockResponseKey) => {
    return mockApplication.setMockResponse(header, queryParameter,mockResponseKey);
  });


    this.Given(/^I fetch the response from mock.*$/, () => {
        return mockApplication.retrieveRecordedRequest();
    });



    this.Then(/^I fetch the response from API by specifying (.*) and (.*)$/, (header,queryParameter) => {
    return aut.getAPIResponse(header, queryParameter)
      .then((response)=>{
        responseBody = response;
      });
  });

  this.Then(/^the api response should match with the expected result file (.*)$/, (expectedResultKey) => {

      console.log('expected: ', responseBody);

      console.log('actual: ', expectedResults.getResponse(expectedResultKey));
      browser.pause(10000);

    assertDiff.deepEqual(expectedResults.getResponse(expectedResultKey),responseBody);
  });

};
