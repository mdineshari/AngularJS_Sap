let sampleApiPerfServiceLib = require('../../../functionalLibs/sampleAPIPerfLib');

module.exports = function() {

  this.Then(/^I measure the performance of (.*) service with default configurations$/, (serviceName) => {
    sampleApiPerfServiceLib.getAPIPerformanceWithDefaultConf(serviceName);
  });

  this.Then(/^I measure the performance of (.*) service with user configurations$/, (serviceName, fields) => {

  });

};
