
var Screenshot = function () {
  var fs = require('fs');


  this.After(function (scenario, callback) {
    if (scenario.isFailed()) {

      var decodedImage = new Buffer('./screenshot.png', 'base64').toString('binary');
      // console.log(__dirname)
      // const image = fs.readFileSync('../../');
      browser.saveScreenshot('./snapshot.png');

      scenario.attach('', "image/png",callback);


    }
  })
};

module.exports = Screenshot;



