let config = require('../../conf/local.conf.js').config;
let performanceLib = require('ob-core-performance-lib').performanceLib;
let uri = require('../../conf/local.conf.js').config.apiEndpointPath;
let perfResult = [];

let self = module.exports = {
    
    getAPIPerformanceWithDefaultConf: (serviceName) => {
        let url = uri[serviceName];
        let eachRequestResult = {};

        //Setting up options to initiate the performance temp
        let options = config['perfConfigurations'];
        options.url = uri[serviceName];
        options.serviceName = serviceName;
        options = performanceLib.setTestStartTimeInOptions(options);
        options.statusCallback = function (error, result, latency) {
            eachRequestResult[result.requestIndex] = result.requestElapsed;
        };

        //Invoking the performance temp
        let response = performanceLib.sendPerformanceRequest(options);

        //Collecting the results of performance temp
        let result = performanceLib.createResult(serviceName, options, eachRequestResult, response);
        perfResult.push(result);
        
        //Validating the result of performance temp
        performanceLib.validatePerformanceTest(response, options);
    },

    getAPIPerformanceWithUserConf: (serviceName) => {
        let eachRequestResult = {};

        //Setting up options to initiate the performance temp
        let options = performanceLib.setExplicitOptions(fields);
        options = performanceLib.setURLInOptions(options, serviceName);
        options = performanceLib.setTestStartTimeInOptions(options);
        options.statusCallback = function (error, result, latency) {
            eachRequestResult[result.requestIndex] = result.requestElapsed;
        };

        //Invoking the performance temp
        let response = performanceLib.sendPerformanceRequest(options);

        //Collecting the results of performance temp
        let result = performanceLib.createResult(serviceName, options, eachRequestResult, response);
        perfResult.push(result);

        //Validating the result of performance temp
        performanceLib.validatePerformanceTest(response, options);
    },

    perfResult: perfResult
};

