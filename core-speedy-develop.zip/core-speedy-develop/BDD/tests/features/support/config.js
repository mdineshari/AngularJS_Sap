module.exports = {
	lookups: {}
};