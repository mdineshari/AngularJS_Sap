const argv = require("yargs").argv;
  override = require('json-override');
  path = require('path');
  const capabilityProvider = require('./runCapabilities.js')  ;
  exclusionTags = ['~@descoped', '~@manual', '~@wip', '~@mocks'];

//************API Declaration Starts************************
const apiEndpoint = require('../endpoints/apiEndpoints.js');
//************API Declaration Ends**************************

process.env.app = (argv.app) ? argv.app : process.env.app;
let app = process.env.app == 'undefined' ? 'mock' : process.env.app;

process.env.instance = (argv.instance) ? argv.instance : process.env.instance;
let instanceConfig = process.env.instance == 'undefined' ? {} : require(`./${process.env.instance}.conf`);

process.env.ff = (argv.ff) ? argv.ff : process.env.ff;
let featureFilePath = process.env.ff == 'undefined' ? `tests/features/featureFiles/web/speedy-JIRA/*.feature` : `tests/features/featureFiles/${argv.ff}.feature`;

process.env.host = (argv.host) ? argv.host : process.env.host;
let hostPath = process.env.host == 'undefined' ? '127.0.0.1' : `${argv.host}`;

process.env.port = (argv.port) ? argv.port : process.env.port;
let portVal = process.env.port == 'undefined' ? '4444' : `${argv.port}`;

process.env.dburl = (argv.dburl) ? argv.dburl : process.env.dburl;
let dbUrl = process.env.dburl == 'undefined' ? 'speedy-speedydev.k8st1.lbg.eu-gb.mybluemix.net' : `${argv.dburl}`;



process.env.sauceUser = (argv.sauceUser) ? argv.sauceUser : process.env.sauceUser;
let sauceUser = process.env.sauceUser == 'undefined' ? '127.0.0.1' : `${argv.sauceUser}`;

process.env.sauceKey = (argv.sauceKey) ? argv.sauceKey : process.env.sauceKey;
let sauceKey = process.env.sauceKey == 'undefined' ? '98d66a73-36f4-4a3a-a766-01b1208a2880' : `${argv.sauceKey}`;

process.env.sauceTunnel = (argv.sauceTunnel) ? argv.sauceTunnel : process.env.sauceTunnel;
let sauceTunnel = process.env.sauceTunnel == 'undefined' ? 'SpeedyTest' : `${argv.sauceTunnel}`;



//************Big Data Declaration Starts***********************
let loginDetails = {
  username: 'USERNAME', //Provide UserName of the cluster
  password: 'PASSWORD'  //Provide Password of the cluster
};


process.env.platform = (argv.platform) ? argv.platform : process.env.platform;
let runPlatform = process.env.platform == 'undefined' ? 'local' : argv.platform;

process.env.browser = (argv.browser) ? argv.browser : process.env.browser;
let runIn = process.env.browser == 'undefined' ? 'chrome' : argv.browser;

process.env.executionType = (argv.executionType) ? argv.executionType : process.env.executionType;
let runType = process.env.executionType == 'undefined' ? false : argv.executionType;


global.envirTest = '${targetBranch}';
global.browserURL = dbUrl;

let localConfig = {

    //**************Browser Config Starts********************

    // host: hostPath,
    // port: portVal,
    // path: '/wd/hub',
    user: '${Sauce_User}',
    key: '${Sauce_Key}',
    connectionRetryTimeout: 900000,
    connectionRetryCount: 10,
    sauceConnect: false,
    protocol: 'https',
    services: ['sauce'],
    seleniumLogs: './tests/reports/selenium-server-logs',

    capabilities: [
        {
            maxInstances: 1,
            'browserName': 'chrome',
            'platform' : 'macOS 10.13',
            'version' : '65.0',
            'tunnelIdentifier': '${Sauce_Tunnel}',
            'maxDuration': 10800,
            'idleTimeout': 9000,
            'commandTimeout': 600,
            'name' : '${Sauce_Tunnel}'
        }
    ],

    //************Browser Config Ends************************


    //************API Config Starts**************************

    app: app,
    apiEndpointPath: apiEndpoint.getEndpoint('local'),
    expectedResponseFolderPath: path.join(__dirname, '../files/expectedResponseFiles/' + app),
    mockDataFolderPath: path.join(__dirname, '../files/mockSourceData'),
    jsonRequestFolderPath: path.join(__dirname, '../files/requestJsonFiles/' + app),
    swaggerFolderPath: path.join(__dirname, '../files/swaggerFiles/'),
    headerFolderPath: 'tests/files/headerFiles/' + app,
    queryParameterFolderPath: 'tests/files/queryParameterFiles/' + app,
    mockPort: 10080,

    //************API Config Ends***************************


    //************MongoDB connection********************
    mongoDbConnection: {
        url: 'mongodb://admin:reset%40123@' + dbUrl + ':27017/',
        dbName: 'hygieiadb'

        // url: 'mongodb://localhost:27017/',
        // dbName: 'SpeedyMDB'
    },



    defaultTags: exclusionTags,
    specs: [featureFilePath],
    sync: true,
    framework: 'cucumber',
    reporters: ['spec'],
    reporterOptions: {
        outputDir: 'tests/reports/output/json'
    },

    TIMEOUTS: {
        minWait: 5000,
        maxWait: 10000
    },

// If you are using Cucumber you need to specify where your step definitions are located.
    cucumberOpts: {
        timeout: 180000,
        require: ['tests/features/step_definitions/', 'tests/features/support/', 'tests/reports/output/'],
        ignoreUndefinedDefinitions: false,
        format: 'json'
    },
    logLevel: 'silent',
    coloredLogs: true
};

exports.config = override(localConfig, app, true);
