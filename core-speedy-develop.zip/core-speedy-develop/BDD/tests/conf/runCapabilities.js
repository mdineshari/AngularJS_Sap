/**
 * Created by prakhare on 05/07/2018.
 */

const path = require('path');
const argv = require('yargs').argv;

module.exports = {
  getCapabilities: function (runPlatform, browser, isHeadlessBrowser, maxInstances) {

    // Set the browser options arguments
    let firefoxOptionsArgs = [];
    let chromeOptionsArgs = [
      'disable-extensions',
      'start-maximized',
      'disable-infobars'
    ];

    if (isHeadlessBrowser) {

      chromeOptionsArgs.push('headless', 'disable-gpu');
      firefoxOptionsArgs.push('-headless');

    }

    // Instantiate the capability object

    if (runPlatform === 'jenkins')
      var capability = {
        maxInstances: maxInstances,
        'browserName': browser,
        'version': '65',
        'platform': 'Windows 7',
        'tunnel-identifier' : '${Sauce_Tunnel}',
        //'seleniumVersion': '3.5.0',
        //'chromedriverVersion':'2.32',
        'maxDuration': 10800,
        'idleTimeout': 900,
        'commandTimeout': 600,
        'name': 'MyTest'
      };

    else if (runPlatform === 'grade1')
      var capability = {
        maxInstances: maxInstances,
        'browserName': 'chrome',
        'version': 'latest',
        'platform': 'Windows 7',
        //'tunnel-identifier' : '${Sauce_Tunnel}',
        'seleniumVersion': '3.5.0',
        'chromedriverVersion':'2.32',
        'maxDuration': 10800,
        'idleTimeout': 900,
        'commandTimeout': 600,
        'name': 'AOO-Bootstrap-BDD-Chrome'
      };

    else
    {
      if (browser === 'chrome') {
        var capability = {
          //maxInstances: maxInstances,
          'browserName': 'chrome',
          'version': 'latest',
          'platform': 'Windows 7',
          //'seleniumVersion': '3.5.0',
          //'chromedriverVersion':'2.32',
          'maxDuration': 10800,
          'idleTimeout': 900,
          'commandTimeout': 600,
          'name': 'AOO-Bootstrap-BDD-Chrome'

        };
      } else if (browser === 'firefox') {
        capability = {
          maxInstances: maxInstances,
          browserName: 'firefox',
          version: null,
          maxDuration: 10800,
          idleTimeout: 900,
          commandTimeout: 600,
        };
      }
      else {
        capability = {
          maxInstances: maxInstances,
          browserName: browser,
          version: null,
          maxDuration: 10800,
          idleTimeout: 900,
          commandTimeout: 600,
          screenResolution: '1024x768'
        }
      }
    }

    // Enhance the capability object based on browser selection
    switch (browser) {
      case 'chrome':
        capability['acceptInsecureCerts'] = true;
        //capability['version'] = 'latest';
        capability['chromeOptions'] = {
          prefs: {
            credentials_enable_service: false,
            profile: {
              password_manager_enabled: false
            }
          },
          args: chromeOptionsArgs
        };
        break;

      case 'firefox':
        capability['moz:firefoxOptions'] = {
          "args": ["-headless"],
          "log": {
            "level": "trace"
          }
        };
        break;

      case 'MicrosoftEdge':
        capability['MicrosoftEdgeOptions'] = {
          nativeEvents: true,
          acceptSslCerts: true,
          javascriptEnabled: true,
          INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS: true,
          cssSelectorsEnabled: true
        };
        break;
      case 'internet explorer':
        capability['InternetExplorerOptions'] = {
          IntroduceInstabilityByIgnoringProtectedModeSettings: true,
          ignoreProtectedModeSettings: true,
          IgnoreProtectedModeSettings: true,
          EnsureCleanSession: true,
          IgnoreZoomLevel: true,
          EnableNativeEvents: false,
          UnexpectedAlertBehaviour: 'InternetExplorerUnexpectedAlertBehaviour.Accept',
          EnablePersistentHover: true,
          'disable-popup-blocking': true
        };
        break;

      default:
    }

    return capability;
  }
};
