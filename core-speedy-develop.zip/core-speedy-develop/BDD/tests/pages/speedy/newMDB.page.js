var assert = require('assert');
// var chai = require('chai');

var database1 = require('../../builders/dbResponse/dBConnectionUpdated.js');
const config = require('../../conf/local.conf.js').config;
const url = config.mongoDbConnection.url;

var feature = '';
var featureCustomHistory = '';
var scope = '';

class newMDB {

    constructor() {
        this.actualIPStoryCount = 0;
        this.clsBugCount = 0;
    }

    countDoc(url1, collectionName){
        // var database1 = new DB;

        database1.data.connectToDB(url)
            .then(
                function() {
                    return database1.data.countDocument(collectionName);
                }, function(err) {
                    throw("Failed to connect to the database: " + err);
                }
            ).then(function(count){
            console.log(count + " documents");
            database1.data.closeConnection();
        }, function(err){
            console.log("Failed to close the documents: " + err);
            database1.data.closeConnection();
        })
    }


    validateFeatureDataDBUpdate(highMediumStoriesInProgressCount, closedBugCount) {

        var options = {};

        var priorityQuery = [
            {
                "$match": {
                    "sProjectName": "Speedy",
                    "sTypeName": "Story",
                    "sStatus": "InProgress",
                    "priority": {
                        "$in": [
                            "Medium",
                            "Highest"
                        ]
                    }
                }
            },
            {
                "$group": {
                    "_id": {},
                    "COUNT(*)": {
                        "$sum": 1
                    }
                }
            },
            {
                "$project": {
                    "_id": 0,
                    "inProgressCount": "$COUNT(*)"
                }
            }
        ];


    }
}
module.exports = newMDB;