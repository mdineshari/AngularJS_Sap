var assert = require('chai').assert;
var chai = require('chai');

const DbClient = require('../../builders/dbResponse/dbConnection.js');
var feature = '';
var featureCustomHistory = '';
var scope = '';

class validateMongoDB {


    validateFeatureDataDB(highMediumStoriesInProgressCount, closedBugCount ) {

        if(highMediumStoriesInProgressCount === undefined || closedBugCount === undefined)
            throw new Error('highMediumStoriesInProgressCount/closedBugCount is not defined');

        let actualIPStoryCount = 0;
        let clsBugCount = 0;


       return DbClient.data.open().then((db)=>{

            var featureData = '';
            // featureData = feature.collection('feature').find( { sStatus: 'Backlog' } ).count();
            var options = {

            };

           var priorityQuery = [
               {
                   "$match": {
                       "sProjectName": "Speedy",
                       "sTypeName": "Story",
                       "priority": {
                           "$in": [
                               "Highest",
                               "Medium"
                           ]
                       },
                       "sStatus": "InProgress"
                   }
               },
               {
                   "$group": {
                       "_id": {},
                       "COUNT(*)": {
                           "$sum": 1
                       }
                   }
               },
               {
                   "$project": {
                       "_id": 0,
                       "inProgressCount": "$COUNT(*)"
                   }
               }
           ];

           var cursor = db.collection('feature').aggregate(priorityQuery, {
               cursor: {batchSize:100}
           });
           // Iterate over all the items in the cursor
           cursor.get(function(err, results) {
               assert.equal(null, err);
               console.log('In Progress Stories with high/medium priority in feature table is : ', results[0].inProgressCount);
               assert.equal(highMediumStoriesInProgressCount, results[0].inProgressCount);
           });


            var mediumClosedBugCount = [
                {
                    "$match": {
                        "sTypeName": "Bug",
                        "sState": "Done",
                        "priority": "Medium",
                        "sProjectName": "Speedy"
                    }
                },
                {
                    "$group": {
                        "_id": {},
                        "COUNT(*)": {
                            "$sum": 1
                        }
                    }
                },
                {
                    "$project": {
                        "_id": 0,
                        "mediumClosedBugCount": "$COUNT(*)"
                    }
                }
            ];

           var cursor1 = db.collection('feature').aggregate(mediumClosedBugCount, {
               cursor: {batchSize:100}
           });
           // Iterate over all the items in the cursor
           cursor1.get(function(err, results) {
               assert.equal(null, err);
               console.log('Count of closed Bugs with medium priority in feature table is : ',results[0].mediumClosedBugCount);
               assert.equal(closedBugCount, results[0].mediumClosedBugCount);
           });


        }).then(()=>{
           DbClient.data.close();
       });

        // chai.expect(actualIPStoryCount).to.be.equal(parseInt(highMediumStoriesInProgressCount));
        // chai.expect(clsBugCount).to.be.equal(parseInt(closedBugCount));
    }

    validateStoryPoint_FeatureCustomHistoryTable(StoryWith5PointEstimate ) {

        if(StoryWith5PointEstimate === undefined )
            throw new Error('StoryWith5PointEstimate is not defined');


        return DbClient.data.open().then((db)=>{

            var featureData = '';
            // featureData = feature.collection('feature').find( { sStatus: 'Backlog' } ).count();
            var options = {

            };

            var storyCountQuery = [
                {
                    "$match": {
                        "projectID": "Speedy",
                        "storyType": "Story",
                        "sEstimate": "5"
                    }
                },
                {
                    "$group": {
                        "_id": {},
                        "COUNT(*)": {
                            "$sum": 1
                        }
                    }
                },
                {
                    "$project": {
                        "_id": 0,
                        "sCount": "$COUNT(*)"
                    }
                }
            ];

            var cursor = db.collection('feature_custom_history').aggregate(storyCountQuery, {
                cursor: {batchSize:100}
            });
            // Iterate over all the items in the cursor
            cursor.get(function(err, results) {
                assert.equal(null, err);
                console.log(' Stories with estimate of 5 Story point in fetaure_custome_history table is : ', results[0].sCount);
                assert.equal(StoryWith5PointEstimate, results[0].sCount);
            });


        }).then(()=>{
            DbClient.data.close();
        });

    }


    validatePID_ScopeTable(PIDScopeTable ) {

        if(PIDScopeTable === undefined )
            throw new Error('PIDScopeTable is not defined');


        return DbClient.data.open().then((db)=>{

            var query = {};
            var projection = {
                "pId": "$pId"
            };


            var cursor = db.collection('scope').find(query).project(projection);

            // Iterate over all the items in the cursor
            cursor.forEach(
                function(doc) {
                    console.log('pID value in scope table for Speedy project is :', doc.pId);
                    assert.equal(PIDScopeTable, doc.pId);
                }
            );


        }).then(()=>{
            DbClient.data.close();
        });

    }

    validatefeatureCustomHistoryTableData(cusHistData) {

        if(cusHistData === undefined )
            throw new Error('PIDScopeTable is not defined');


        return DbClient.data.open().then((db)=>{

            var query = {};
            var projection = {
                "pId": "$pId"
            };

            var cursor = db.collection('scope').find(query).project(projection);

            // Iterate over all the items in the cursor
            cursor.forEach(
                function(doc) {
                    console.log('pID value in scope table for Speedy project is :', doc.pId);
                    assert.equal(cusHistData, doc.pId);
                }
            );


        }).then(()=>{
            DbClient.data.close();
        });

    }



}

module.exports = validateMongoDB;