const NativePage = require('../native.page.js');
const actionLib = require('ob-core-ui-lib').actionsLib;
const verifyLib = require('ob-core-ui-lib').verifyLib;
const speedyPageData = require('../../files/testData/speedy/speedy.data.js');

class speedySettingPage extends NativePage {

  get getPageElement() {
    return this.getPage('speedy/locators');
  }

  /*openwebdriverIOHomepage() {
    actionLib.OpenURL(webdriverIOHomePageData['url']);
  }*/

  openSpeedyPage() {
      console.log('browser url', browserURL);
    actionLib.OpenURL('http://' + browserURL);
  }

  enterLoginDetails() {
      if(verifyLib.IsAnyVisible(this.getPageElement.adminToggle)==false){
          actionLib.AddValue(this.getPageElement.username, speedyPageData['username']);
          browser.pause(1000);
          actionLib.AddValue(this.getPageElement.password, speedyPageData['password']);
          browser.pause(1000);
          actionLib.Click(this.getPageElement.loginBtn);
          browser.pause(1000);
      }
  }

  validateWelcomePage() {
      verifyLib.IsAnyVisible(this.getPageElement.adminToggle);
  }

  openDashboard(dashboardName) {
    verifyLib.IsAnyVisible(this.getPageElement.adminToggle);
    actionLib.Click(this.getPageElement.dashboard.replace('xxxx',dashboardName));
  }

  validateDashboardData(projectName, openStoryCount, wipCount, doneCount) {

    if(verifyLib.VerifyText(this.getPageElement.projectName_Dashboard, projectName)==false){
      throw new Error('Project verification failed');
    }
    if(verifyLib.VerifyText(this.getPageElement.openStoryCount_Dashboard, openStoryCount)==false)
    {
        throw new Error('open Story Count verification failed');
    }

    if(verifyLib.VerifyText(this.getPageElement.wipStoryCount_Dashboard, wipCount)==false)
    {
        throw new Error('wip Count verification failed');
    }
    if(verifyLib.VerifyText(this.getPageElement.doneStoryCount_Dashboard, doneCount)==false)
    {
        throw new Error('done Count verification failed');
    }
      browser.pause(7000);
  }

  openSettingsFromAdminToggle() {
      actionLib.Click(this.getPageElement.adminToggle);
  }

  updateRefreshFreqAndJiraURL() {
      actionLib.Click(this.getPageElement.settingsInToggle);
      actionLib.Click(this.getPageElement.settingsSection);
      actionLib.Click(this.getPageElement.jiraTab);
      actionLib.Click(this.getPageElement.jiraURL);
      browser.pause(2000);

      // -------------Please uncomment below code to set JIRA URL value------

      browser.clearElement('input[placeholder="JIRA URL"]');
      browser.pause(2000);
      actionLib.AddValue(this.getPageElement.jiraURL, 'https://jira.devops.lloydsbanking.com');

      if(browser.isEnabled(this.getPageElement.submitButton)){
          browser.pause(3000);
          browser.keys("Enter");
          browser.pause(3000);
          if(browser.isEnabled(this.getPageElement.continueButton)){
              browser.click(this.getPageElement.continueButton);
          }
      }
  }

  validatemongoDBData() {

  }
}

module.exports = speedySettingPage;
