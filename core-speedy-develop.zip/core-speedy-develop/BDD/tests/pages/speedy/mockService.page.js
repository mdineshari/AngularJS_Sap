var assert = require('chai').assert;
var chai = require('chai');

var mockserver = require('mockserver-node');

class mockService {

    // startMockServer (){
    //     console.log('mock server started');
    //     mockserver.start_mockserver({serverPort: 1080});
    // }
    //
    // stopMockServer (){
    //     console.log('mock server stopped');
    //     mockserver.stop_mockserver();
    // }

}

module.exports = mockService;