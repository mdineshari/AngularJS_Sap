var mockService = require('./mockService.page.js');
var mServ = new mockService();


mServ.startMockServer();
// mServ.stopMockServer();