const config = require('../../conf/local.conf.js').config;
var mockServerNode = require('mockserver-node');
const mockServer = require('mockserver-client').mockServerClient("localhost", 1080);
console.log("../../files/headerFiles/" + config.app + "/sampleApiHeader");
// let headers = require(`../../files/headerFiles/${config.app}/sampleApiHeader`).headerList;
// let queryParams = require(`../../files/queryParameterFiles/${config.app}/sampleApiQueryParameter`).queryParamList;
let mockDataSet = require('../../files/mockSourceData/sampleApiMock').mockData;

module.exports = {

  startmockServer :  () => {
    return mockServerNode.start_mockserver({serverPort: 1080});
  },

  stopmockServer :  () => {
    return mockServerNode.stop_mockserver();
  },


  retrieveRecordedRequest : () => {

    return mockServer.retrieveRecordedRequests({
      "path": "/findCustomerDetails",
      "method": "Get"
    })
        .then(
            function (recordedRequests) {
              console.log(JSON.stringify(recordedRequests));
            },
            function (error) {
              console.log(error);
            }
        );

  },

  setMockResponse: (header, queryParameter,mockResponseKey) => {

    let headerData = headers.getHeaders(header);
    let propertiesObject = queryParams.getQueryParams(queryParameter);
    let mockData = mockDataSet.getMockData(mockResponseKey);

    console.log('AN : ', propertiesObject.AccountNumber);
    console.log('SC : ', propertiesObject.SortCode);

    return mockServer.mockAnyResponse({
      'httpRequest': {
        'method': 'GET',
        'path': '/findCustomerDetails',
        'queryStringParameters': [
          {
            'name': 'AccountNumber',
            'values': [propertiesObject.AccountNumber]
          },
          {
            'name': 'SortCode',
            'values': [propertiesObject.SortCode]
          }
        ],

        'headers': [
          {
            "name": "ProductType",
            "values": [headerData.ProductType]
          }
        ]
      },
      'httpResponse': {
        'statusCode': 200,
        'body': JSON.stringify(mockData)
      },
      'times': {
        'unlimited': true
      }
    });
  }
};
