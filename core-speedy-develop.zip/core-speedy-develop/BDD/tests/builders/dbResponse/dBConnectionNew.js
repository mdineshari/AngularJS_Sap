
// dbDataLoopExample.js
//
// This is a simple test script that does the following:
//  Connect to mongoDB database
//  Add records to user collection
//  Read the records from database
//  Loop through each record to populate form fields, then submit the form
//  Wait for results page
//  Verify first / last name on the results page

var webdriverio = require('webdriverio');
var should = require('should');
var Q = require('q');

// use promise-mongo - see https://www.npmjs.com/package/promise-mongo
var PM = require('promise-mongo');
var pm = new PM();
var collectionNames = [ 'features' ];
var db;
var cf;
var cur;

// this.timeout(20000);

// loopTest()

 module.exports =  {

    // set timeout to 20 seconds


     loopTest : function(abc){
       console.log('loopTest func val is : ',abc);
     },


     connect : function (done) {
        // connect to the db
        pm.initDb(collectionNames, 'mongodb://localhost:27017/SpeedyMDB').then(function(mdb) {
            console.log('Connected to db');
            db = pm.cols;
            cf = pm.cf;
            cur = pm.cur;
        }).then(function(res){
            console.log('inside then --');
            done();
        });
    },

    addData : function(done) {
        db.user.insert({fname: 'Jim', lname: 'Smith'}).then(function() {
            return db.user.findOne({ fname: 'Jim'});
        }).then(function(res) {
            console.log('Added: ' + res.fname + ' ' + res.lname);
            (res.fname).should.be.equal('Jim');
            (res.lname).should.be.equal('Smith');
            // only one done()
            done();
        });
    },

    processData : function() {
        // Special thanks to Christian Bromann <mail@christian-bromann.com> for help with this code.
        var loop = Q();
        // var cursor = db.collection('feature').aggregate(priorityQuery, {
        //     cursor: {batchSize:100}
        // });

        return db.collection('feature').aggregate(priorityQuery, {
            cursor: {batchSize:100}
        }).then(cur.toArray).then(function(res) {
            console.log('Records:', res.length);
            res.forEach(function(d) {
                loop = loop.then(function() {
                    // execute the next function after the previous has resolved successfully
                    console.log(d.inProgressCount);
                    return this.loopTest(d.inProgressCount);
                });
            });
            // return last so mocha knows all records are finished.
            return loop;
        });
    },

    // drop the database when finished
    dropDB : function(done) {
        pm.mdb.dropDatabase(function(err, result) {
            done();
        });
    }


};

