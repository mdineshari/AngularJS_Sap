var assert = require('chai').assert;
var chai = require('chai');

const DbClient = require('./dbConnection');
var feature = '';
var featureCustomHistory = '';
var scope = '';

class validateMongoDB {
    validateFeatureData(highMediumStoriesInProgressCount, closedBugCount ) {
         DbClient.data.open().then((db)=>{

                var featureData = '';
                // featureData = feature.collection('feature').find( { sStatus: 'Backlog' } ).count();
                var options = {

                };

                var priorityQuery = [
                    {
                        "$match": {
                            "sProjectName": "Speedy",
                            "sTypeName": "Story",
                            "sStatus": "InProgress",
                            "priority": {
                                "$in": [
                                    "Medium",
                                    "Highest"
                                ]
                            }
                        }
                    },
                    {
                        "$group": {
                            "_id": {},
                            "COUNT(*)": {
                                "$sum": 1
                            }
                        }
                    },
                    {
                        "$project": {
                            "_id": 0,
                            "inProgressCount": "$COUNT(*)"
                        }
                    }
                ];
                var featureObj = db.collection('feature');

                featureObj.aggregate(priorityQuery, options, function (err, result) {
                    if (err) console.log(err);
                    result.forEach(
                        function(doc) {
                            console.log(doc.inProgressCount);
                            if(parseInt(doc.inProgressCount)==10){
                                console.log('in progress count match....');
                            }else{
                                return false;
                                // throw new Error('in Progress count mismatch');
                            }
                        }
                    );
                });

                // var mediumClosedBugCount = [
                //     {
                //         "$match": {
                //             "sTypeName": "Bug",
                //             "sState": "Done",
                //             "priority": "Medium",
                //             "sProjectName": "Speedy"
                //         }
                //     },
                //     {
                //         "$group": {
                //             "_id": {},
                //             "COUNT(*)": {
                //                 "$sum": 1
                //             }
                //         }
                //     },
                //     {
                //         "$project": {
                //             "_id": 0,
                //             "mediumClosedBugCount": "$COUNT(*)"
                //         }
                //     }
                // ];
                //
                // featureObj.aggregate(mediumClosedBugCount, options, function (err, result) {
                //     if (err) console.log(err);
                //     result.forEach(
                //         function(doc) {
                //             console.log(doc.mediumClosedBugCount);
                //         }
                //     );
                // });

        })
    }
}

module.exports = validateMongoDB;
