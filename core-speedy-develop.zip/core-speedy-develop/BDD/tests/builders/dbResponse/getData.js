const DbClient = require('./dbConnection');
var feature = '';
var featureCustomHistory = '';
var scope = '';

DbClient.data.open().then((db)=>{
        console.log('connection in new');
        });


//
// module.exports = {
//     'getDbObject': DbClient.data.open().then((db)=>{
//         console.log('connection in new');
//         }
//     //     {
//     //
//     //     try{
//     //
//     //             var featureData = '';
//     //
//     //             // featureData = feature.collection('feature').find( { sStatus: 'Backlog' } ).count();
//     //             var options = {
//     //
//     //             };
//     //
//     //             var priorityQuery = [
//     //                 {
//     //                     "$match": {
//     //                         "priority": {
//     //                             "$not": {
//     //                                 "$in": [
//     //                                     "Highest",
//     //                                     "Medium"
//     //                                 ]
//     //                             }
//     //                         },
//     //                         "sProjectName": "Speedy"
//     //                     }
//     //                 },
//     //                 {
//     //                     "$group": {
//     //                         "_id": {},
//     //                         "COUNT(priority)": {
//     //                             "$sum": 1
//     //                         }
//     //                     }
//     //                 },
//     //                 {
//     //                     "$project": {
//     //                         "_id": 0,
//     //                         "priorityCount": "$COUNT(priority)"
//     //                     }
//     //                 }
//     //             ];
//     //             featureObj = db.collection('feature');
//     //
//     //             featureObj.aggregate(priorityQuery, options, function (err, result) {
//     //                 if (err) console.log(err);
//     //                 result.forEach(
//     //                     function(doc) {
//     //                         console.log(doc.priorityCount);
//     //                     }
//     //                 );
//     //             });
//     //
//     //             var mediumClosedBugCount = [
//     //                 {
//     //                     "$match": {
//     //                         "sTypeName": "Bug",
//     //                         "sState": "Done",
//     //                         "priority": "Medium",
//     //                         "sProjectName": "Speedy"
//     //                     }
//     //                 },
//     //                 {
//     //                     "$group": {
//     //                         "_id": {},
//     //                         "COUNT(*)": {
//     //                             "$sum": 1
//     //                         }
//     //                     }
//     //                 },
//     //                 {
//     //                     "$project": {
//     //                         "_id": 0,
//     //                         "mediumClosedBugCount": "$COUNT(*)"
//     //                     }
//     //                 }
//     //             ];
//     //
//     //             featureObj.aggregate(mediumClosedBugCount, options, function (err, result) {
//     //                 if (err) console.log(err);
//     //                 result.forEach(
//     //                     function(doc) {
//     //                         console.log(doc.mediumClosedBugCount);
//     //                     }
//     //                 );
//     //             });
//     //     }
//     //     finally {
//     //
//     //         DbClient.data.close();
//     //     }
//     //
//     // }
//     ),
//
//
// };
