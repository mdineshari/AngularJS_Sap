'use strict';
const config = require('../../conf/local.conf.js').config;
const url = config.mongoDbConnection.url;
const dbName = config.mongoDbConnection.dbName;
const mongoClient = require('mongodb').MongoClient;

function open(){

    // Connection URL. This is where your mongodb server is running.
     return new Promise((resolve, reject)=>{
        // Use connect method to connect to the Server
         mongoClient.connect(url, (err, db) => {
            console.log("Connected successfully to server");
            if (err) {
                reject(err);
            } else {
                console.log('connection established----');
                resolve(db.db(dbName));
            }
        });
    });
}

function close(db){
    //Close connection
    if(db){
        db.close();
    }
}

var data = {
    open : open,
    close: close
};

module.exports.data = data;