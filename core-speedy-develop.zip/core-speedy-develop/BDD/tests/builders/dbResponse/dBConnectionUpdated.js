// 'use strict';
// const config = require('../../conf/local.conf.js').config;
// const url = config.mongoDbConnection.url;
// const dbName = config.mongoDbConnection.dbName;
// const MongoClient = require('mongodb').MongoClient;
// const assert = require('assert');
//
// (async function() {
//     let client;
//
//     let options = {
//
//     };
//
//     let priorityQuery = [
//         {
//             "$match": {
//                 "sProjectName": "Speedy",
//                 "sTypeName": "Story",
//                 "sStatus": "InProgress",
//                 "priority": {
//                     "$in": [
//                         "Medium",
//                         "Highest"
//                     ]
//                 }
//             }
//         },
//         {
//             "$group": {
//                 "_id": {},
//                 "COUNT(*)": {
//                     "$sum": 1
//                 }
//             }
//         },
//         {
//             "$project": {
//                 "_id": 0,
//                 "inProgressCount": "$COUNT(*)"
//             }
//         }
//     ];
//
//     try {
//         client = await MongoClient.connect(url);
//         console.log("Connected correctly to server");
//
//         const db = client.db(dbName);
//
//         // Insert a single document
//         // db.collection('feature').aggregate(priorityQuery, options, function(err, result){
//         //     assert.equal(null, err);
//         //     assert.equal('good', result[0].inProgressCount);
//         // });
//
//         var cursor = db.collection('feature').aggregate(priorityQuery, {
//             cursor: {batchSize:100}
//         });
//
//         // Iterate over all the items in the cursor
//         cursor.get(function(err, results) {
//             assert.equal(null, err);
//             assert.equal('good', results[0].inProgressCount);
//             db.close();
//         });
//
//
//
//     } catch (err) {
//         console.log(err.stack);
//     }
//
//     // Close connection
//     client.close();
// })();
//
//
// //
// //
// //
// //     function DB() {
// //         this.db = null;
// //     }
// //
// //     DB.prototype.connectToDB = function(url) {
// //         var _this = this;
// //
// //         return new Promise(function(resolve, reject){
// //             if(_this.db){
// //                 console.log('already connected');
// //                 resolve();
// //             }
// //             else{
// //                 var thisRef = _this;
// //
// //                 MongoClient
// //                     .connect(url).then(function (database){
// //                     thisRef.db = database;
// //                     resolve();
// //                 }, function(err){
// //                     console.log("Error connecting: " + err.message);
// //                     reject(err.message);
// //                 })
// //             }
// //         })
// //     };
// //
// //      DB.prototype.countDocument = function(coll) {
// //         var _this = this;
// //         return new Promise(function(resolve, reject){
// //             _this.db.collection(coll, {strict:true}, function(error, collection){
// //                 if(error) {
// //                     console.log("Could not access collection: " + error.message);
// //                     reject(error.message);
// //                 } else {
// //                     collection.count()
// //                         .then(function(count){
// //                             resolve();
// //                         }, function(err){
// //                             console.log("countDocuments failed: " + err.message);
// //                             reject(err.message);
// //                         })
// //                 }
// //             })
// //         })
// //     };
// //
// //     DB.prototype.closeConnection = function() {
// //         if(this.db) {
// //             this.db.close()
// //                 .then(function() {}, function(error) {
// //                     console.log("Failed to close the database: " + error.message)
// //                 })
// //         }
// //     };
// //
// // var data = {
// //     connectToDB : DB.prototype.connectToDB,
// //     countDocument : DB.prototype.countDocument,
// //     closeConnection: DB.prototype.closeConnection
// // };
// //
// // module.exports.data = data;