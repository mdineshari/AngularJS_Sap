const request = require('request-promise');
const config = require('../../conf/local.conf.js').config;
let uri = require('../../conf/local.conf.js').config.apiEndpointPath;
let headers = require(`../../files/headerFiles/${config.app}/sampleApiHeader`).headerList;
let queryParams = require(`../../files/queryParameterFiles/${config.app}/sampleApiQueryParameter`).queryParamList;
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
module.exports = {
  getAPIResponse: (header, queryParameter) => {

    let headerData = headers.getHeaders(header);
    let propertiesObject = queryParams.getQueryParams(queryParameter);
    let url = uri['sampleApi'];

    const getOptions = {
      method: 'GET',
      uri: url,
      qs: propertiesObject,
      headers: headerData,
      rejectUnauthorized: false,
      followRedirect: false,
      json: true
    };

    const postOptions = {
        method: 'POST',
        uri: url,
        headers: headerData,
        rejectUnauthorized: false,
        followRedirect: false,
        json: true
    };
    return request(getOptions);
  },

  postAPI: (header) => {
    const options = {
        method: 'POST',
        uri: 'https://speedy-speedytest.k8st1.lbg.eu-gb.mybluemix.net/api/login?username=admin&password=Admin@123',
        headers: {
            "Accept": "application/json, text/plain, */*",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "en-US,en;q=0.9",
            "Authorization": "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbiIsImRldGFpbHMiOiJTVEFOREFSRCIsInJvbGVzIjpbIlJPTEVfVVNFUiIsIlJPTEVfQURNSU4iXSwiZXhwIjoxNTI2OTE1NTkwfQ.HvvTMMyIHb0xo1_FIULsK4fTwrdTZKNljaxfJIN0lJb8tB-a3vYmSW-Ye47-1M88RaEYlBEWfDIBZl034d-9_A",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Cookie": "JSESSIONID=442EDAAB9DD6334869CD2A098352BD91; _ga=GA1.6.1078826832.1526900505; _gid=GA1.6.317056401.1526900505; __VCAP_ID__=6f5d7584-c724-4714-625d-0fb496e8de58; _gat_UA-114130163-1=1",
            "Host": "speedy-speedytest.k8st1.lbg.eu-gb.mybluemix.net",
            "Pragma": "no-cache",
            "Referer": "https://speedy-speedytest.k8st1.lbg.eu-gb.mybluemix.net/"
        },
        json: true
    };
    return request(options);
  }
};
