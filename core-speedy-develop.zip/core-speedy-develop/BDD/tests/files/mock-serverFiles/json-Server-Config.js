// server.js

var jsonServer = require('json-server');
var server = jsonServer.create();
var router;
var middlewares;

module.exports = {
    
    startjsonServer : ()=>{
        router = jsonServer.router('db.json');
        middlewares = jsonServer.defaults({ watch : true });

        server.use(middlewares);
        server.use(router);
        server.listen(3001, function () {
            console.log('JSON Server is running')
        });
    }
};

//
// var mockServer = require('node-mock-server');
// var path = require('path');
//
// mockServer({
//     restPath: path.join(__dirname, '/mock/rest'),
//     dirName: __dirname,
//     title: 'Api mock server',
//     version: 2,
//     urlBase: 'http://localhost:3001',
//     urlPath: '/rest/v2',
//     port: 3001,
//     uiPath: '/',
//     // funcPath: path.join(__dirname, '/func'),
//     headers: {
//         'Global-Custom-Header': 'Global-Custom-Header'
//     },
//     // customDTOToClassTemplate: path.join(__dirname, '/templates/dto_es6flow.ejs'),
//     // swaggerImport: {
//     //     protocol: 'http',
//     //     authUser: undefined,
//     //     authPass: undefined,
//     //     host: 'petstore.swagger.io',
//     //     port: 80,
//     //     path: '/v2/swagger.json',
//     //     dest: path.join(__dirname, '/mock/rest'),
//     //     replacePathsStr: '/v2/{baseSiteId}',
//     //     createErrorFile: true,
//     //     createEmptyFile: true,
//     //     overwriteExistingDescriptions: true,
//     //     responseFuncPath: path.join(__dirname, '/func-imported')
//     // },
//     open: true
// });