var baseConfig = {
    bulk_queries: [
        // Query 1
        {
            query: "insert into bankacct_txn_by_sortcode_acct(account_sort_code,account_number,unc_mode_indicator,dr_cr_ind,sequence_number," +
            "transaction_amount,transaction_posted_date)values(111111,11024568,0,'D',47898765429107370019,109.567,'2017-02-14')"
        },
        // Query 2
        {
            query: "insert into bankacct_txn_by_sortcode_acct(account_sort_code,account_number,unc_mode_indicator,dr_cr_ind,sequence_number," +
            "transaction_amount,transaction_posted_date)values(222222,11987511,0,'C',98798765429107370019,10.57,'2017-01-14')"
        }
    ]
};
exports.config = baseConfig;