var commonUtils = require('../../../features/functionalLibs/commonUtils');

var self = {
    headers: {
        "Header_Default": {
            "ProductType": "BCA"
        },

        "TC_1_Header": {
            "ProductType": "BCA"
        },

        "Speedy_Login_Header": {
            "Accept": "application/json, text/plain, */*",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "en-US,en;q=0.9",
            "Authorization": "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbiIsImRldGFpbHMiOiJTVEFOREFSRCIsInJvbGVzIjpbIlJPTEVfVVNFUiIsIlJPTEVfQURNSU4iXSwiZXhwIjoxNTI2OTE1NTkwfQ.HvvTMMyIHb0xo1_FIULsK4fTwrdTZKNljaxfJIN0lJb8tB-a3vYmSW-Ye47-1M88RaEYlBEWfDIBZl034d-9_A",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "Cookie": "JSESSIONID=442EDAAB9DD6334869CD2A098352BD91; _ga=GA1.6.1078826832.1526900505; _gid=GA1.6.317056401.1526900505; __VCAP_ID__=6f5d7584-c724-4714-625d-0fb496e8de58; _gat_UA-114130163-1=1",
            "Host": "speedy-speedydev.k8st1.lbg.eu-gb.mybluemix.net",
            "Pragma": "no-cache",
            "Referer": "https://speedy-speedydev.k8s.lbg.eu-gb.mybluemix.net/"
        }
    },

    getHeaders: function (expectedHeaderKey) {
        console.log('expectedHeaderKey:-------', expectedHeaderKey)
        // return commonUtils.getOverriddenData(self.headers, 'Header_Default', expectedHeaderKey);
    }
};

exports.headerList = self;
