package com.capitalone.dashboard.auth;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.atlassian.crowd.integration.springsecurity.user.CrowdUserDetails;
import com.capitalone.dashboard.auth.ldap.CustomUserDetails;
import com.capitalone.dashboard.service.CustomAnalyticsService;
import com.capitalone.dashboard.service.UserAuthenticationService;

@Component
public class AuthenticationResultHandler implements AuthenticationSuccessHandler {

	@Autowired
	private AuthenticationResponseService authenticationResponseService;

	@Autowired
	private CustomAnalyticsService customAnalyticsService;

	@Autowired
	private UserAuthenticationService userAuthenticationService;

	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException {
		authenticationResponseService.handle(response, authentication);
		// sgu106: Google Analytics data population starts
		String userName = authentication.getPrincipal().toString();
		if (authentication.getPrincipal() instanceof CustomUserDetails) {
			userName = ((CustomUserDetails) authentication.getPrincipal()).getUsername();
		}
		if (authentication.getPrincipal() instanceof CrowdUserDetails) {
			userName = ((CrowdUserDetails) authentication.getPrincipal()).getUsername();
		}
		JSONObject json = customAnalyticsService.addAnalyticsData(response, userName);
		userAuthenticationService.checkForSecurityQuestion(json, userName);
		
		response.getOutputStream().print(json.toJSONString());
		// sgu106: Google Analytics data population ends
	}
}
