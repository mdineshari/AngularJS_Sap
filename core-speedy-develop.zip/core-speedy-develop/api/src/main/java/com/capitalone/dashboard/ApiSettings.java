package com.capitalone.dashboard;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class ApiSettings {
	/**
	 * TODO The property name 'key' is too vague. This key is used only for
	 * encryption. Would suggest to rename it to encryptionKey to be specific. For
	 * now (for backwards compatibility) keeping it as it was.
	 */
	private String encryptionKey;
	@Value("${corsEnabled:false}")
	private boolean corsEnabled;
	private String corsWhitelist;
	private boolean logRequest;

	private String instanceOwner;
	private String userName;
	private String accountName;
	private String projectName;
	private String analyticsConfigDescPath;
	private Map<String,String> crowd;

	public String getEncryptionKey() {
		return encryptionKey;
	}

	public void setEncryptionKey(final String key) {
		this.encryptionKey = key;
	}

	public boolean isCorsEnabled() {
		return corsEnabled;
	}

	public void setCorsEnabled(boolean corsEnabled) {
		this.corsEnabled = corsEnabled;
	}

	public String getCorsWhitelist() {
		return corsWhitelist;
	}

	public void setCorsWhitelist(String corsWhitelist) {
		this.corsWhitelist = corsWhitelist;
	}

	public boolean isLogRequest() {
		return logRequest;
	}

	public void setLogRequest(boolean logRequest) {
		this.logRequest = logRequest;
	}

	public String getInstanceOwner() {
		return instanceOwner;
	}

	public void setInstanceOwner(String instanceOwner) {
		this.instanceOwner = instanceOwner;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getAnalyticsConfigDescPath() {
		return analyticsConfigDescPath;
	}

	public void setAnalyticsConfigDescPath(String analyticsConfigDescPath) {
		this.analyticsConfigDescPath = analyticsConfigDescPath;
	}

	public Map<String, String> getCrowd() {
		return crowd;
	}

	public void setCrowd(Map<String, String> crowd) {
		this.crowd = crowd;
	}

	
}
