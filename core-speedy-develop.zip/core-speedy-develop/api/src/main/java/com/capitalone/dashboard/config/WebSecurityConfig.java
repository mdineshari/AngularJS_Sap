package com.capitalone.dashboard.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.codehaus.xfire.aegis.type.CustomTypeMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.Http401AuthenticationEntryPoint;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.ldap.authentication.ad.ActiveDirectoryLdapAuthenticationProvider;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.atlassian.crowd.integration.http.HttpAuthenticator;
import com.atlassian.crowd.integration.http.HttpAuthenticatorImpl;
import com.atlassian.crowd.integration.springsecurity.CrowdAuthenticationProvider;
import com.atlassian.crowd.integration.springsecurity.CrowdSSOAuthenticationProcessingFilter;
import com.atlassian.crowd.integration.springsecurity.RemoteCrowdAuthenticationProvider;
import com.atlassian.crowd.integration.springsecurity.user.CrowdUserDetailsService;
import com.atlassian.crowd.integration.springsecurity.user.CrowdUserDetailsServiceImpl;
import com.atlassian.crowd.service.AuthenticationManager;
import com.atlassian.crowd.service.GroupManager;
import com.atlassian.crowd.service.cache.BasicCache;
import com.atlassian.crowd.service.cache.CacheImpl;
import com.atlassian.crowd.service.cache.CachingGroupManager;
import com.atlassian.crowd.service.cache.CachingGroupMembershipManager;
import com.atlassian.crowd.service.cache.CachingUserManager;
import com.atlassian.crowd.service.cache.SimpleAuthenticationManager;
import com.atlassian.crowd.service.soap.client.SecurityServerClient;
import com.atlassian.crowd.service.soap.client.SecurityServerClientImpl;
import com.atlassian.crowd.service.soap.client.SoapClientProperties;
import com.atlassian.crowd.service.soap.client.SoapClientPropertiesImpl;
import com.capitalone.dashboard.ApiSettings;
import com.capitalone.dashboard.auth.AuthProperties;
import com.capitalone.dashboard.auth.AuthenticationResultHandler;
import com.capitalone.dashboard.auth.apitoken.ApiTokenAuthenticationProvider;
import com.capitalone.dashboard.auth.apitoken.ApiTokenRequestFilter;
import com.capitalone.dashboard.auth.ldap.CustomUserDetailsContextMapper;
import com.capitalone.dashboard.auth.ldap.LdapLoginRequestFilter;
import com.capitalone.dashboard.auth.standard.StandardLoginRequestFilter;
import com.capitalone.dashboard.auth.token.JwtAuthenticationFilter;
import com.capitalone.dashboard.model.AuthType;

@Configuration
@EnableWebSecurity
@EnableConfigurationProperties
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	private static final String CROWD_SESSION_VALIDATION_INTERVAL_VALUE = "sessionValidationInterval";

	private static final String SERVER_URL_VALUE = "serverUrl";

	private static final String APPLICATION_PASSWORD_VALUE = "applicationPassword";

	private static final String APPLICATION_NAME_VALUE = "applicationName";

	private static final String APPLICATION_LOGIN_URL_VALUE = "applicationLoginUrl";

	private static final String SESSION_VALIDATION_INTERVAL_KEY = "session.validationinterval";

	private static final String CROWD_SERVER_URL_KEY = "crowd.server.url";

	private static final String APPLICATION_PASSWORD_key = "application.password";

	private static final String APPLICATION_NAME_KEY = "application.name";

	private static final String APPLICATION_LOGIN_URL_KEY = "application.login.url";

	@Autowired
	private JwtAuthenticationFilter jwtAuthenticationFilter;

	@Autowired
	private AuthenticationResultHandler authenticationResultHandler;

	@Autowired
	private AuthenticationProvider standardAuthenticationProvider;

	@Autowired
	private ApiTokenAuthenticationProvider apiTokenAuthenticationProvider;

	@Autowired
	private AuthProperties authProperties;

	@Autowired
	private ApiSettings apiSettings;

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.headers().cacheControl();
		http.csrf().disable().authorizeRequests().antMatchers("/appinfo").permitAll().antMatchers("/registerUser")
				.permitAll().antMatchers("/createUser")//.permitAll().antMatchers("/excel/downloadOfflineData")
				.permitAll().antMatchers("/login**").permitAll().antMatchers("/authenticationProviders").permitAll()
				.antMatchers("/login/captcha").permitAll().antMatchers("/speedy/getversionmetadata").permitAll()
				.antMatchers("/login/captchavalidate").permitAll()
				.antMatchers("/cache/clearAllCache").permitAll().antMatchers("/cache/clearCache/**").permitAll()
				.antMatchers("/resetPassword").permitAll()
				// TODO: sample call secured with ROLE_API
				// .antMatchers("/ping").hasAuthority("ROLE_API")
				//.antMatchers(HttpMethod.GET, "/**").permitAll()

				// Temporary solution to allow jenkins plugin to send data to
				// the api
				// TODO: Secure with API Key
				//.antMatchers(HttpMethod.POST, "/build").permitAll().antMatchers(HttpMethod.POST, "/deploy").permitAll()
				//.antMatchers(HttpMethod.POST, "/performance").permitAll().antMatchers(HttpMethod.POST, "/artifact")
				//.permitAll().antMatchers(HttpMethod.POST, "/quality/test").permitAll()
				//.antMatchers(HttpMethod.POST, "/quality/static-analysis").permitAll()
				// Temporary solution to allow Github webhook
				//.antMatchers(HttpMethod.POST, "/commit/github/v3").permitAll()
				.anyRequest().authenticated().and()
				.addFilterBefore(standardLoginRequestFilter(), UsernamePasswordAuthenticationFilter.class)
				.addFilterBefore(ldapLoginRequestFilter(), UsernamePasswordAuthenticationFilter.class)
				.addFilterBefore(crowdSSOAuthenticationProcessingFilter(), UsernamePasswordAuthenticationFilter.class)
				.addFilterBefore(apiTokenRequestFilter(), UsernamePasswordAuthenticationFilter.class)
				.addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class)
				.exceptionHandling().authenticationEntryPoint(new Http401AuthenticationEntryPoint("Authorization"));
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		List<AuthType> authenticationProviders = authProperties.getAuthenticationProviders();

		if (authenticationProviders.contains(AuthType.STANDARD)) {
			auth.authenticationProvider(standardAuthenticationProvider);
		}

		if (authenticationProviders.contains(AuthType.LDAP)) {
			//configureLdapP(auth);
			configureActiveDirectoryP(auth);
			//configureLdap(auth);
			configureActiveDirectory(auth);
		}
		if (authenticationProviders.contains(AuthType.CROWDSSO)) {
			auth.authenticationProvider(crowdAuthenticationProvider());
		}


		auth.authenticationProvider(apiTokenAuthenticationProvider);
	}

	@Bean
	CrowdAuthenticationProvider crowdAuthenticationProvider() throws IOException {
		return new RemoteCrowdAuthenticationProvider(crowdAuthenticationManager(), httpAuthenticator(),
				crowdUserDetailsService());
	}
	
	private void configureActiveDirectory(AuthenticationManagerBuilder auth) {
		ActiveDirectoryLdapAuthenticationProvider adProvider = activeDirectoryLdapAuthenticationProvider();
		if (adProvider != null)
			auth.authenticationProvider(adProvider);
	}

	private void configureActiveDirectoryP(AuthenticationManagerBuilder auth) {
		ActiveDirectoryLdapAuthenticationProvider adProvider = activeDirectoryLdapAuthenticationProviderP();
		if (adProvider != null)
			auth.authenticationProvider(adProvider);
	}

	/*private void configureLdap(AuthenticationManagerBuilder auth) throws Exception {
		String ldapServerUrl = authProperties.getLdapServerUrl();
		String ldapUserDnPattern = authProperties.getLdapUserDnPattern();
		if (StringUtils.isNotBlank(ldapServerUrl) && StringUtils.isNotBlank(ldapUserDnPattern)) {
			auth.ldapAuthentication().userDnPatterns(ldapUserDnPattern).contextSource().url(ldapServerUrl);
		}
	}

	private void configureLdapP(AuthenticationManagerBuilder auth) throws Exception {
		String ldapServerUrl = null;
		String ldapUserDnPattern = authProperties.getLdapUserDnPattern();
		if (StringUtils.isNotBlank(ldapServerUrl) && StringUtils.isNotBlank(ldapUserDnPattern)) {
			auth.ldapAuthentication().userDnPatterns(ldapUserDnPattern).contextSource().url(ldapServerUrl);
		}
	}
*/
	@Bean
	protected StandardLoginRequestFilter standardLoginRequestFilter() throws Exception {
		return new StandardLoginRequestFilter("/login", authenticationManager(), authenticationResultHandler);
	}

	@Bean
	protected LdapLoginRequestFilter ldapLoginRequestFilter() throws Exception {
		return new LdapLoginRequestFilter("/login/ldap", authenticationManager(), authenticationResultHandler);
	}

	@Bean
	protected ApiTokenRequestFilter apiTokenRequestFilter() throws Exception {
		return new ApiTokenRequestFilter("/**", authenticationManager(), authenticationResultHandler);
	}

	@Bean
	protected ActiveDirectoryLdapAuthenticationProvider activeDirectoryLdapAuthenticationProvider() {
		if (StringUtils.isBlank(authProperties.getAdUrl()))
			return null;

		ActiveDirectoryLdapAuthenticationProvider provider = new ActiveDirectoryLdapAuthenticationProvider(
				authProperties.getAdDomain(), authProperties.getAdUrl(), authProperties.getAdRootDn());
		provider.setConvertSubErrorCodesToExceptions(true);
		provider.setUseAuthenticationRequestCredentials(true);
		provider.setUserDetailsContextMapper(new CustomUserDetailsContextMapper());
		return provider;
	}

	@Bean
	protected ActiveDirectoryLdapAuthenticationProvider activeDirectoryLdapAuthenticationProviderP() {
		if (StringUtils.isBlank(authProperties.getAdLionsUrl()))
			return null;

		ActiveDirectoryLdapAuthenticationProvider provider = new ActiveDirectoryLdapAuthenticationProvider(
				authProperties.getAdLionsDomain(), authProperties.getAdLionsUrl(), authProperties.getAdRootDn());
		provider.setConvertSubErrorCodesToExceptions(true);
		provider.setUseAuthenticationRequestCredentials(true);
		provider.setUserDetailsContextMapper(new CustomUserDetailsContextMapper());
		return provider;
	}

	public static Properties getProps() throws IOException {
		Properties prop = new Properties();
		try (InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream("crowd.properties")) {
			prop.load(in);
		}
		return prop;
	}
	
	//@Bean
	public CrowdSSOAuthenticationProcessingFilter crowdSSOAuthenticationProcessingFilter() throws Exception {
		CrowdSSOAuthenticationProcessingFilter filter = new CrowdSSOAuthenticationProcessingFilter();
		filter.setHttpAuthenticator(httpAuthenticator());
		filter.setAuthenticationManager(authenticationManager());
		// filter.setAuthenticationFailureHandler(
		// authenticationFailureHandler() );
		filter.setAuthenticationSuccessHandler(authenticationResultHandler);
		filter.setFilterProcessesUrl("/login/crowdsso");
		return filter;
	}
	
	@Bean
	public CrowdUserDetailsService crowdUserDetailsService() throws IOException {
		CrowdUserDetailsServiceImpl crowdUserDetailsService = new CrowdUserDetailsServiceImpl();
		crowdUserDetailsService.setUserManager(userManager());
		crowdUserDetailsService.setAuthorityPrefix("");
		crowdUserDetailsService.setGroupMembershipManager(
				new CachingGroupMembershipManager(securityServerClient(), userManager(), groupManager(), cache()));
		return crowdUserDetailsService;
	}
	
	@Bean()
	public HttpAuthenticator httpAuthenticator() throws IOException {
		return new HttpAuthenticatorImpl(crowdAuthenticationManager());
	}
	
	@Bean
	public AuthenticationManager crowdAuthenticationManager() throws IOException {
		return new SimpleAuthenticationManager(securityServerClient());
	}

	@Bean
	public GroupManager groupManager() throws IOException {
		return new CachingGroupManager(securityServerClient(), cache());
	}

	@Bean
	public CachingUserManager userManager() throws IOException {
		return new CachingUserManager(securityServerClient(), cache());
	}

	@Bean
	public SecurityServerClient securityServerClient() throws IOException {
		return new SecurityServerClientImpl(soapClientProperties());
	}
	
	@Bean
	public SoapClientProperties soapClientProperties() throws IOException {
		Properties prop = new Properties();

		if (apiSettings.getCrowd() != null) {
			prop.put(APPLICATION_LOGIN_URL_KEY, apiSettings.getCrowd().get(APPLICATION_LOGIN_URL_VALUE));
			prop.put(APPLICATION_NAME_KEY, apiSettings.getCrowd().get(APPLICATION_NAME_VALUE));
			prop.put(APPLICATION_PASSWORD_key, apiSettings.getCrowd().get(APPLICATION_PASSWORD_VALUE));
			prop.put(CROWD_SERVER_URL_KEY, apiSettings.getCrowd().get(SERVER_URL_VALUE));
			prop.put(SESSION_VALIDATION_INTERVAL_KEY,
					apiSettings.getCrowd().get(CROWD_SESSION_VALIDATION_INTERVAL_VALUE));
		}
		return SoapClientPropertiesImpl.newInstanceFromProperties(prop);
	}

	@Bean
	public BasicCache cache() {
		return new CacheImpl(Thread.currentThread().getContextClassLoader().getResource("crowd-ehcache.xml"));
	}
}
