Sprint 4 (Current)
=========================
 * SPEEDY-131 - Adding update.js and rollback.js file. Currently added the properties that are being added for Jira # SPEEDY-135.

Sprint 3
=========================

 * SPEEDY-120 - Merging exercise(New Properties files taken from Sapient Repository)
 * SPEEDY-55 - Reduce the default JIRA poll interval
 * SPEEDY-84 - Change JIRA Collector defaults to match target workflow
 * SPEEDY-111 - JIRA Collector issue if no team name provided
 * SPEEDY-109 - Sonar Tech Build widget is not coming correctly
 * SRDEVOPSDA-668 :  deployment collectors uDeploy,XL Deploy have been added into combine collector
 * SRDEVOPSDA-652: Lloyds | Tech Debt widget shows No Data Available in Speedy even though stories are marked with appropriate label
 * SRDEVOPSDA-653 : Lloyds | DIR not showing up datails
 * SRDEVOPSDA-661: Lloyds | Maturity Radar | Functional test execution time maturity level incorrect
 * SRDEVOPSDA-662 : Lloyds | Missing/extra widgets in Maturity Radar
 * SRDEVOPSDA-636 - Host version provider service on any centre server CLOSED
 