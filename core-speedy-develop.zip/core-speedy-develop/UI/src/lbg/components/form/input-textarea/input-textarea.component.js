function InputTextareaController($scope, $element, $attrs) {
  var ctrl = this;

  ctrl.$onChanges = function() {
    ctrl.placeholder = ctrl.placeholder || ctrl.name;
  };
}

angular.module('LBG.Components').component('lbgInputTextarea', {
  templateUrl: 'lbg/components/form/input-textarea/input-textarea.component.html',
  bindings: {
    value: '=',
    name: '@',
    description: '@'
  },
  controller: InputTextareaController
});