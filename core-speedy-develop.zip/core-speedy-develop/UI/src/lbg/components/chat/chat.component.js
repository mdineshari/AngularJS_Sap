function ChatController($scope, $element, $attrs, $http, $timeout) {
  var ctrl = this;


  ctrl.$onInit = function () {

    if(!ctrl.messages) ctrl.messages = [];

    $scope.$watch('$ctrl.messages', function (newVal, oldVal) {
      $timeout(function () {
        var scroller = $(".panel-body")[0];
        scroller.scrollTop = scroller.scrollHeight;
      }, 0, false);
    });
  };

  ctrl.showHide = function () {
    this.minimised = !this.minimised;
  };

  ctrl.tell = function (input) {

    var payload = {
      "currentNode": "",
      "complete": null,
      "context": {},
      "parameters": [],
      "extractedParameters": {},
      "speechResponse": "",
      "intent": {},
      "input": input,
      "missingParameters": []
    };

    $http.post('http://localhost:8080/gateway/api/v1', payload)
      .then(function() {
        ctrl.messages = ctrl.messages.concat({
          type: "answer",
          copy: res.data.speechResponse[0]
        });
      })
      .catch(function(){
        ctrl.messages = ctrl.messages.concat({
          type: "error",
          copy: 'Chat bot is asleep'
        });
      });
  };

  ctrl.sendQuestion = function () {

    ctrl.messages = ctrl.messages.concat({
      type: "question",
      copy: this.question
    });

    var payload = {
      "currentNode": "",
      "complete": null,
      "context": {},
      "parameters": [],
      "extractedParameters": {},
      "speechResponse": "",
      "intent": {},
      "input": this.question,
      "missingParameters": []
    };

    this.question = null;

    $http.post('http://localhost:8080/gateway/api/v1', payload)
      .then(function() {

        ctrl.messages = ctrl.messages.concat({
          type: "answer",
          copy: res.data.speechResponse[0]
        });

      })
      .catch(function(){
        ctrl.messages = ctrl.messages.concat({
          type: "error",
          copy: 'Chat bot is asleep'
        });
      });
  };

}

angular.module('LBG.Components').component('lbgChat', {
  templateUrl: 'lbg/components/chat/chat.component.html',
  bindings: {
    messages: '<'
  },
  controller: ChatController
});