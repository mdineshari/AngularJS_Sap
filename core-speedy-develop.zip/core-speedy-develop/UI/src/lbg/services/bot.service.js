'use strict';

angular
  .module('LBG.Services')
  .service('BotService', botService);

botService.$inject = ['$http'];

function botService($http) {
   this.post = function (payload) {
    return $http.post('http://localhost:8080/gateway/api/v1');
  };
};