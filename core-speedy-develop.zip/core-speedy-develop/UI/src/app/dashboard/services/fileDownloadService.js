/**
 * Service to handle all user operations
 */
(function() {
	'use strict';

	angular.module(HygieiaConfig.module).service('fileDownloadService',
			fileDownloadService);

	fileDownloadService.$inject = [ '$http', '$q' ];
	function fileDownloadService($http, $q) {
		this.downloadFileToUrl = function() {
			var downloadUrl = "/api/excel/downloadOfflineData"; // Url of
																// webservice/api/server
			var deffered = $q.defer();
			$http({
				method : 'GET',
				url : downloadUrl,
				responseType : 'arraybuffer'
			}).success(function(data, status, headers) {
				headers = headers();
				var filename = headers['x-filename'];
				var contentType = headers['content-type'];
				var linkElement = document.createElement('a');
				try {
					var blob = new Blob([ data ], {
						type : contentType
					});
					var url = window.URL.createObjectURL(blob);
					linkElement.setAttribute('href', url);
					linkElement.setAttribute("download", filename);
					var clickEvent = new MouseEvent("click", {
						"view" : window,
						"bubbles" : true,
						"cancelable" : false
					});
					linkElement.dispatchEvent(clickEvent);
		    		
					deffered.resolve(blob,filename,status,url);
				} catch (ex) {
					deffered.reject(ex,null,status);
				}
			}).error(function(data, status) {
				var message = '';
				if(status === 404) {
					message = 'File not available to download'
				} else if(status === 500) {
					message = 'Internal Server Error';
				}
				deffered.reject(message,null,status);
			});
			return deffered.promise;
		}
	}
})();