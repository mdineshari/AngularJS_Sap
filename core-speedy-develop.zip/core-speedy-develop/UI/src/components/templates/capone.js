/***********
 * Controller for the dashboard route.
 * Render proper template.
 */
(function () {
    'use strict';

    angular
        .module(HygieiaConfig.module)
        .controller('CapOneTemplateController', CapOneTemplateController);

    CapOneTemplateController.$inject = ['$scope', '$rootScope'];

    function CapOneTemplateController($scope, $rootScope) {
    	
        var ctrl = this;
        var teamName = $.parseJSON(localStorage.getItem('teamUrlMapData'))[window.location.hostname];
        if(teamName) {
      	  ga('set', 'dimension1', teamName);
        } else {
      	  ga('set', 'dimension1', window.location.hostname);
        }
        ga('set', 'dimension2', localStorage.getItem('currentSpeedyVersion'));
        ga('send', {
        	hitType: 'event',
        	eventCategory: 'Dashboard',
        	eventAction: 'Dashboard Accessed',
        	eventLabel: 'Engineering Dashboard'
        });
        
        ctrl.selectedSCM = null;

        ctrl.tabs = [{
                name: "Widget"
            },
            {
                name: "Pipeline"
            },
            {
                name: "Cloud"
            }
        ];

        ctrl.dashboardGlobalData = dashboardGlobalData;

        ctrl.generateName = function (url) {
            return _.last(url.split('/'));
        }


        ctrl.minitabs = [{
                name: "Quality"
            },
            {
                name: "QualityJS"
            },
            {
                name: "Performance"
            },
            {
                name: "Security"
            },
            {
                name: "Accessibility"
            }

        ];

        ctrl.widgetView = ctrl.tabs[0].name;
        ctrl.toggleView = function (index) {
            ctrl.widgetView = typeof ctrl.tabs[index] === 'undefined' ? ctrl.tabs[0].name : ctrl.tabs[index].name;
        };

        //Mini Widget View
        ctrl.miniWidgetView = ctrl.minitabs[0].name;
        ctrl.miniToggleView = function (index) {
            ctrl.miniWidgetView = typeof ctrl.minitabs[index] === 'undefined' ? ctrl.minitabs[0].name : ctrl.minitabs[index].name;
        };

        /*
        //  Quality widget
        */

        // check to see if any of the repo widgets have been set to show, otherwise show first as default
        ctrl.NoQualities = false;
        var codeQualityCollectorItems = ctrl.dashboardGlobalData.application.components[0].collectorItems.CodeQuality;           
        ctrl.codeQualities = _.filter(codeQualityCollectorItems, {options: {codeQualityIdentifier : 'BE'}});
        
        _.each(ctrl.codeQualities, function (quality) {
        	if(quality.show) ctrl.selectedQuality = quality;
        });
        if(!ctrl.selectedQuality && ctrl.dashboardGlobalData.application.components[0] && ctrl.codeQualities.length > 0) {
        	ctrl.codeQualities[0].show = true;
            ctrl.selectedQuality = ctrl.codeQualities[0];
        } else if(ctrl.codeQualities.length <=0) {
        	ctrl.NoQualities = true;
        }
        
        //  This shows tabed Qualities
        ctrl.showQualityWidget = function (quality) { 
            var codeQualityCollectorItems = ctrl.dashboardGlobalData.application.components[0].collectorItems.CodeQuality;           
            ctrl.codeQualities = _.filter(codeQualityCollectorItems, {options: {codeQualityIdentifier : 'BE'}});
            if(ctrl.codeQualities.length <=0) {
            	ctrl.NoQualities = true;
            } else {
            	ctrl.NoQualities = false;
            }
        	_.each(ctrl.codeQualities, function (item) {
                item.show = false;
            });
            ctrl.selectedQuality = _.find(ctrl.dashboardGlobalData.application.components[0].collectorItems.CodeQuality, {id: quality.id});
            ctrl.selectedQuality.show = true;
        }
        
        //  Temp work around to allow calling Quality widget function 
        ctrl.qualityWidgetFunctions = {
            showQualityWidget: ctrl.showQualityWidget
        }; 

        /*
        //  QualityJS widget
        */

        // check to see if any of the repo widgets have been set to show, otherwise show first as default
        ctrl.NoQualityJS = false;
        var codeQualityJSCollectorItems = ctrl.dashboardGlobalData.application.components[0].collectorItems.CodeQuality;           
        ctrl.codeQualityJS = _.filter(codeQualityJSCollectorItems, {options: {codeQualityIdentifier : 'FE'}});
        _.each(ctrl.codeQualityJS, function (qualityJS) {
            if(qualityJS.show) ctrl.selectedQualityJS = qualityJS;
        });
        if(!ctrl.selectedQualityJS && ctrl.dashboardGlobalData.application.components[0] && ctrl.codeQualityJS.length > 0) {
        	ctrl.codeQualityJS[0].show = true;
            ctrl.selectedQualityJS = ctrl.codeQualityJS[0];
        } else if(ctrl.codeQualityJS.length <=0) {
        	ctrl.NoQualityJS = true;
        }

        //  This shows tabed repos
        ctrl.showQualityJSWidget = function (qualityJS) { 
            var codeQualityJSCollectorItems = ctrl.dashboardGlobalData.application.components[0].collectorItems.CodeQuality;           
            ctrl.codeQualityJS = _.filter(codeQualityJSCollectorItems, {options: {codeQualityIdentifier : 'FE'}});
            if(ctrl.codeQualityJS.length <=0) {
            	ctrl.NoQualityJS = true;
            } else {
            	ctrl.NoQualityJS = false;
            }
        	_.each(ctrl.codeQualityJS, function (item) {
                item.show = false;
            });
            ctrl.selectedQualityJS = _.find(ctrl.dashboardGlobalData.application.components[0].collectorItems.CodeQuality, {options: {codeQualityIdentifier : 'FE'}, id: qualityJS.id});
            ctrl.selectedQualityJS.show = true;
        }

        //  Temp work around to allow calling QualityJS widget function 
        ctrl.qualityJSWidgetFunctions = {
            showQualityJSWidget: ctrl.showQualityJSWidget
        };                


        /*
         * Build Widget
         */
        
        var addBuild = {};

        addBuild.description = "Add New";

        ctrl.dashboardGlobalData.application.components[0].collectorItems.Build = ctrl.dashboardGlobalData.application.components[0].collectorItems.Build || [];

        var buildArray = [];
        for (var g = 0; g < ctrl.dashboardGlobalData.application.components[0].collectorItems.Build.length; g++) {
            var buildId = ctrl.dashboardGlobalData.application.components[0].collectorItems.Build[g].id;
            if (ctrl.dashboardGlobalData.widgets) {
                for (var f = 0; f < ctrl.dashboardGlobalData.widgets.length; f++) {
                    if (buildId == ctrl.dashboardGlobalData.widgets[f].collectorItemIds[0] && ctrl.dashboardGlobalData.widgets[f].name == "build") {
                        buildArray.push(JSON.parse(JSON.stringify(ctrl.dashboardGlobalData.application.components[0].collectorItems.Build[g])));
                    }
                }
            }
        }
        ctrl.dashboardGlobalData.application.components[0].collectorItems.Build = [];
        ctrl.dashboardGlobalData.application.components[0].collectorItems.Build = buildArray;
        var buildLen = ctrl.dashboardGlobalData.application.components[0].collectorItems.Build.length;
        var addNewPresent = false;


        for (var i = 0; i < buildLen; i++) {
            if (ctrl.dashboardGlobalData.application.components[0].collectorItems.Build[i].description == "Add New") {
                addNewPresent = true;
            }
        }

        if (!addNewPresent) {
            ctrl.dashboardGlobalData.application.components[0].collectorItems.Build.push(addBuild);
        }

        ctrl.miniBuildWidgetView = ctrl.dashboardGlobalData.application.components[0].collectorItems.Build[0].description;

        ctrl.miniBuildToggleView = function (index) {


            ctrl.dashboardGlobalData = dashboardGlobalData;
            var addBuild = {};

            addBuild.description = "Add New";
            ctrl.dashboardGlobalData.application.components[0].collectorItems.Build = ctrl.dashboardGlobalData.application.components[0].collectorItems.Build || [];

            var buildLen = ctrl.dashboardGlobalData.application.components[0].collectorItems.Build.length;
            var addNewPresent = false;

            for (var i = 0; i < buildLen; i++) {
                if (ctrl.dashboardGlobalData.application.components[0].collectorItems.Build[i].description == "Add New") {
                    addNewPresent = true;
                }
            }

            if (!addNewPresent) {
                ctrl.dashboardGlobalData.application.components[0].collectorItems.Build.push(addBuild);
            }
            ctrl.miniBuildWidgetView = ctrl.dashboardGlobalData.application.components[0].collectorItems.Build[0].description;

            ctrl.miniBuildWidgetView = typeof ctrl.dashboardGlobalData.application.components[0].collectorItems.Build[index] === 'undefined' ? ctrl.dashboardGlobalData.application.components[0].collectorItems.Build[0].description : ctrl.dashboardGlobalData.application.components[0].collectorItems.Build[index].description;
        };

        /*
        //  Repo (SCM) widget
        */

        // check to see if any of the repo widgets have been set to show, otherwise show first as default
        _.each(ctrl.dashboardGlobalData.application.components[0].collectorItems.SCM, function (scm) {
            if(scm.show) ctrl.selectedSCM = item;
        });
        if(!ctrl.selectedSCM && ctrl.dashboardGlobalData.application.components[0] && ctrl.dashboardGlobalData.application.components[0].collectorItems.SCM) {
            ctrl.dashboardGlobalData.application.components[0].collectorItems.SCM[0].show = true;
            ctrl.selectedSCM = ctrl.dashboardGlobalData.application.components[0].collectorItems.SCM[0];
        }
        
        //  This shows tabed repos
        ctrl.showRepoWidget = function (scm) {
            _.each(ctrl.dashboardGlobalData.application.components[0].collectorItems.SCM, function (item) {
                item.show = false;
            });
            ctrl.selectedSCM = scm;
            scm.show = true;
        }

        $scope.$watch('$root.logoImage', function () {
            ctrl.logoImage = $rootScope.logoImage;
        });

        //  Temp work around to allow calling repo widget function 
        ctrl.repoWidgetFunctions = {
            showRepoWidget: ctrl.showRepoWidget
        };        

    }

})();
