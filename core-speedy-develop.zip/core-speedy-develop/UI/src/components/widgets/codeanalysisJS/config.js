/**
 * Code Analysis widget configuration
 */
(function () {
    'use strict';

    angular
        .module(HygieiaConfig.module)
        .controller('CodeAnalysisJSConfigController', CodeAnalysisJSConfigController);

    CodeAnalysisJSConfigController.$inject = ['modalData', '$scope', 'collectorData', '$uibModalInstance', '$window'];
    function CodeAnalysisJSConfigController(modalData, $scope, collectorData, $uibModalInstance, $window) {
        var ctrl = this,
        widgetConfig = modalData.widgetConfig,
        component = modalData.dashboard.application.components[0],
        opts = modalData.opts;
        ctrl.errorMessage = '';
		//  If not id passed, clear widget so modal config is empty
		if (!opts.collectoritemid) {
			ctrl.flag = true;
		} else {
			ctrl.flag = false;
			// Else get the config options for the currently selected widget
	        var codeQualityCollectorItems = component.collectorItems.CodeQuality;           
	        codeQualityCollectorItems = _.filter(codeQualityCollectorItems, {options: {codeQualityIdentifier : 'FE'}});
			var selectedQuality = _.find(codeQualityCollectorItems, function (item) {
				return item.show;
			});
			if (selectedQuality) {
                ctrl.caCollectorItem = selectedQuality;
                ctrl.oldCaCollectorItemId = selectedQuality.id;
                widgetConfig.collectorItemId = opts.collectoritemid;
			}
		}

        ctrl.saToolsDropdownPlaceholder = 'Loading Security Analysis Jobs...';
        ctrl.ossToolsDropdownPlaceholder = 'Loading Open Source Scanning Jobs...';
        ctrl.testToolsDropdownPlaceholder = 'Loading Functional Test Jobs...';

        // public methods
        ctrl.caLoading = true;
        ctrl.submit = submitForm;
        ctrl.addTestConfig = addTestConfig;
        ctrl.deleteTestConfig = deleteTestConfig;
        ctrl.collectors = [];
        ctrl.delete = deleteQuality;
		function deleteQuality(form) {
			collectorData.deleteCollectorItem({
				dashboardId: opts.dashboard.id,
				componentId: widgetConfig.componentId,
				collectorId: widgetConfig.collectorItemId,
				widgetType: 'CodeQuality'
			});
			$uibModalInstance.close();
			setTimeout(function() { window.location.reload();}, 10);
		}
		
        $scope.getCodeQualityCollectors = function(filter){
        	return collectorData.itemsByType('codequality', {"search": filter, "size": 20}).then(function (response){
        		return response;
        	});
        };

        loadSavedCodeQualityJob();

        // request all the codequality and test collector items
        collectorData.itemsByType('staticSecurityScan').then(processSaResponse);
        collectorData.itemsByType('test').then(processTestsResponse);
        collectorData.itemsByType('libraryPolicy').then(processOSSscanResponse);

        function loadSavedCodeQualityJob(){
            ctrl.qualityId ="";
            var codeQualityCollectorItems = component.collectorItems.CodeQuality;           
            codeQualityCollectorItems = _.filter(codeQualityCollectorItems, {options: {codeQualityIdentifier : 'FE'}});
            ctrl.savedCollectorQualityJobs = codeQualityCollectorItems;
            var savedCodeQualityJob = codeQualityCollectorItems.length > 0 ? codeQualityCollectorItems[0].description : null;
            
            if(savedCodeQualityJob){
            	for(var i=0;i<codeQualityCollectorItems.length;i++){
            		if(codeQualityCollectorItems[i].description==savedCodeQualityJob){
            			ctrl.qualityId = codeQualityCollectorItems[i].id;
            		}
            	}
            	$scope.getCodeQualityCollectors(savedCodeQualityJob).then(getCodeQualityCollectorsCallback) ;
            }
        }

        function getCodeQualityCollectorsCallback(data) {
        	_(data).forEach(function (item) {
                if(item.id == ctrl.qualityId){
                    ctrl.collectorItemId = item;
                    ctrl.collectors.push(item);
                }
            });
        }

        function processSaResponse(data) {
            var saCollectorItems = component.collectorItems.StaticSecurityScan;
            var saCollectorItemId = _.isEmpty(saCollectorItems) ? null : saCollectorItems[0].id;

            ctrl.saJobs = data;
            ctrl.saCollectorItem = saCollectorItemId ? _.find(ctrl.saJobs, {id: saCollectorItemId}) : null;
            ctrl.saToolsDropdownPlaceholder = data.length ? 'Select a Security Analysis Job' : 'No Security Analysis Job Found';
        }

        function processOSSscanResponse(data) {
            var ossCollectorItems = component.collectorItems.LibraryPolicy;
            var ossCollectorItemId = _.isEmpty(ossCollectorItems) ? null : ossCollectorItems[0].id;

            ctrl.ossJobs = data;
            ctrl.ossCollectorItem = ossCollectorItemId ? _.find(ctrl.ossJobs, {id: ossCollectorItemId}) : null;
            ctrl.ossToolsDropdownPlaceholder = data.length ? 'Select a Open Source Scan Job' : 'No Open Source Scan Found';

        }

        function processTestsResponse(data) {
            ctrl.testJobs = data;
            ctrl.testConfigs = [];
            var testCollectorItems = component.collectorItems.Test;
            var testCollectorItemIds = [];
            var testJobNamesFromWidget = [];
            // set values from config
            if (widgetConfig) {
                if (widgetConfig.options.testJobNames) {
                    var j;
                    for (j = 0; j < widgetConfig.options.testJobNames.length; ++j) {
                        testJobNamesFromWidget.push(widgetConfig.options.testJobNames[j]);
                    }
                }
            }
            var index;
            if (testCollectorItems != null) {
                for (index = 0; index < testCollectorItems.length; ++index) {
                    testCollectorItemIds.push(testCollectorItems[index].id);
                }
            }
            for (index = 0; index < testCollectorItemIds.length; ++index) {
                var testItem = testCollectorItemIds ? _.find(ctrl.testJobs, {id: testCollectorItemIds[index]}) : null;
                ctrl.testConfigs.push({
                    testJobName: testJobNamesFromWidget[index],
                    testJob: ctrl.testJobs,
                    testCollectorItem: testItem
                });
            }
            ctrl.testToolsDropdownPlaceholder = data.length ? 'Select a Functional Test Job' : 'No Functional Test Jobs Found';
        }
        ctrl.changeJob = changeJob;

        function changeJob(obj) {
            ctrl.isExist = false;
            return ctrl.savedCollectorQualityJobs.some(function(el) {
                if(el.id === obj.id) {
                    ctrl.isExist = true;
                    ctrl.errorMessage = 'This Job is already added in this widget';
                    return;
                }
            }); 
        }

        function submitForm(caCollectorItem, saCollectorItem, ossCollectorItem, testConfigs) {
            ctrl.errorMessage='';
            if(ctrl.oldCaCollectorItemId && caCollectorItem.id === ctrl.oldCaCollectorItemId) {
                $uibModalInstance.close();
                return;
            }
            if(typeof(caCollectorItem) == 'string'){
                ctrl.errorMessage = 'Please select the Job from the code analysis field, before save';
                return;
            } else {
                ctrl.errorMessage = '';
            }
            
            var collectorItems = [];
            var testJobNames = [];
            if (caCollectorItem) collectorItems.push(caCollectorItem.id);
            if (saCollectorItem) collectorItems.push(saCollectorItem.id);
            if (ossCollectorItem) collectorItems.push(ossCollectorItem.id);
            if (testConfigs) {
                var index;
                for (index = 0; index < testConfigs.length; ++index) {
                    collectorItems.push(testConfigs[index].testCollectorItem.id);
                    testJobNames.push(testConfigs[index].testJobName);
                }
            }
            //Modified for Update functionality for Build Widget -- Dinesh M Jira ID: core-speedy-993 starts
            if(!ctrl.flag) {
                var postObj = {
                    delete: {
                        dashboardId: opts.dashboard.id,
                        componentId: widgetConfig.componentId,
                        collectorId: ctrl.oldCaCollectorItemId,
                        widgetType: 'CodeQuality'
                    },
                    add: {
                        name: 'codeanalysis',
                        options: {
                            codeQualityIdentifier : 'FE',
                            id: widgetConfig.options.id,
                            testJobNames: testJobNames
                        },
                        componentId: component.id,
                        collectorItemId: caCollectorItem.id
                    }
                };
            } else {
                var postObj = {
                    name: 'codeanalysis',
                    options: {
                        codeQualityIdentifier : 'FE',
                        id: widgetConfig.options.id,
                        testJobNames: testJobNames
                    },
                    componentId: component.id,
                    collectorItemId: caCollectorItem.id
                };
            }
            //Modified for Update functionality for Build Widget -- Dinesh M Jira ID: core-speedy-993 ends
            
            // pass this new config to the modal closing so it's saved
            $uibModalInstance.close(postObj);
            setTimeout(function(){
               $window.location.reload(); 
             },500);
        }


        function addTestConfig() {
            var newItemNo = ctrl.testConfigs.length + 1;
            ctrl.testConfigs.push({testJobName: 'Name' + newItemNo, testJob: ctrl.testJobs, testCollectorItem: null});
        }

        function deleteTestConfig(item) {
            ctrl.testConfigs.pop(item);
        }
    }
})();
