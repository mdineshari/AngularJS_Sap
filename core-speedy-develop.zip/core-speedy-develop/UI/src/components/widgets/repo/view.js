(function () {
  'use strict';

  angular
    .module(HygieiaConfig.module)
    .controller('RepoViewController', RepoViewController);

  RepoViewController.$inject = ['$q', '$scope', 'repoData', 'collectorData', '$uibModal'];

  function RepoViewController($q, $scope, repoData, collectorData, $uibModal) {
    var ctrl = this;

    var labels = [];
    ctrl.summary = {};
    ctrl.churn = {};

    var detailsGroupedByDay = {};

    var types = {
      commits: 0,
      pulls: 1,
      issues: 2,
      deletes: 3,
      checkouts: 4,
      activeUsers: 5
    }

    ctrl.combinedChartOptions = {
      plugins: [
        Chartist.plugins.gridBoundaries(),
        Chartist.plugins.lineAboveArea(),
        Chartist.plugins.pointHalo(),
        Chartist.plugins.ctPointClick({
          onClick: showDetail
        }),
        Chartist.plugins.axisLabels({
          stretchFactor: 1.4,
          axisX: {
            labels: [
              moment().subtract(14, 'days').format('MMM DD'),
              moment().subtract(7, 'days').format('MMM DD'),
              moment().format('MMM DD')
            ]
          }
        }),
        Chartist.plugins.ctPointLabels({
          textAnchor: 'middle'
        })
      ],

      showArea: false,
      lineSmooth: false,
      fullWidth: true,
      axisY: {
        offset: 25,
        showGrid: true,
        showLabel: true,
        labelInterpolationFnc: function (value) {
          return Math.round(value * 100) / 100;
        }
      }
    };

    ctrl.commits = [];
    ctrl.pulls = [];
    ctrl.issues = [];

    ctrl.showDetail = showDetail;
    ctrl.load = function () {

      var deferred = $q.defer();
      var params = {
        componentId: $scope.widgetConfig.componentId,
        numberOfDays: 14,
        collectorItemId: $scope.collectoritemid
      };

      labels = _.times(params.numberOfDays, function () {
        return '';
      });

      ctrl.combinedChartData = {
        labels: labels,
        series: new Array(5)
      };

      repoData.details(params)
        .then(function (data) {
          if(data.commitResponse && data.commitResponse.result.length) processResponse('commits', data.commitResponse.result, params.numberOfDays);
          if(data.pullResponse && data.pullResponse.result.length) processResponse('pulls', data.pullResponse.result, params.numberOfDays);
          if(data.issueResponse && data.issueResponse.result.length) processResponse('issues', data.issueResponse.result, params.numberOfDays);
          if(data.deleteResponse && data.deleteResponse.result.length) processResponse('deletes', data.deleteResponse.result, params.numberOfDays);
          if(data.checkoutResponse && data.checkoutResponse.result.length) processResponse('checkouts', data.checkoutResponse.result, params.numberOfDays);
          if(data.activeUsersResponse && data.activeUsersResponse.result.length) processResponse('activeUsers', data.activeUsersResponse.result, params.numberOfDays);
          if(data.componentChurn && data.componentChurn.result) {
        	  
        	 
        	  var currentWidget = _.find(dashboardGlobalData.application.components[0].collectorItems.SCM, function(scm){
        		  return scm.id === $scope.collectoritemid;
        	  });
              ctrl.churn = _.filter(_.map(data.componentChurn.result, function(value, key){
            	  return {
            		  key: key,
            		  value: value
            	  };
              }), function(churn){
            	  return churn.value > currentWidget.options.churnThreshold;
              });
          }

          ctrl.repoName = '';
          ctrl.lastUpdated = data.lastUpdated;
          if(data.commitResponse.result[0]) {
        	  if(data.commitResponse.result[0].scmName) ctrl.repoName = data.commitResponse.result[0].scmName;
          }

        })
        .then(function () {
          //  Not sure if this is needed...
            collectorData.getCollectorItem($scope.widgetConfig.componentId, 'scm')
            .then(function (data) {
              deferred.resolve({
                lastUpdated: ctrl.lastUpdated,
                collectorItem: data
              });
            });
        });

      return deferred.promise;
    };

    function showDetail(evt) {
      var target = evt.target,
        pointIndex = target.getAttribute('ct:point-index');

      var seriesIndex = target.getAttribute('ct:series-index');
      
      $uibModal.open({
        controller: 'RepoDetailController',
        controllerAs: 'detail',
        templateUrl: 'components/widgets/repo/detail.html',
        size: 'lg',

        resolve: {
          repoName: function(){
        	return  ctrl.repoName;
          },
          commits: function () {
            if (seriesIndex == "0")
              return detailsGroupedByDay['commits'][pointIndex];
          },
          pulls: function () {
            if (seriesIndex == "1")
              return detailsGroupedByDay['pulls'][pointIndex];
          },
          issues: function () {
            if (seriesIndex == "2")
              return detailsGroupedByDay['issues'][pointIndex];
          },
          deletes: function () {
            if (seriesIndex == "3")
              return detailsGroupedByDay['deletes'][pointIndex];
          },
          checkouts: function () {
            if (seriesIndex == "4")
              return detailsGroupedByDay['checkouts'][pointIndex];
          },
          activeUsers: function () {
            if (seriesIndex == "5")
              return detailsGroupedByDay['activeUsers'][pointIndex];
          }
        }
      });
    }

    function processResponse(type, data, numberOfDays) {
    	
      var groupByDay = _(data)
        .sortBy('timestamp')
        .reject(function(item){
          return item.scmCommitTimestamp === 0
        })
        .groupBy(function (item) {

          if(item.scmCommitTimestamp === 0) console.log('got zero');

          item.date = moment(item.scmCommitTimestamp).format('D/MMM');
          // console.log(item.date)
          return (numberOfDays - 1) - moment().endOf('day').diff(moment(item.scmCommitTimestamp), 'days');
        })
        .value();


      // Keep the group by day data for the modal detail view
      detailsGroupedByDay[type] = groupByDay;

      var chartData = _.times(numberOfDays, function (n) {
        return groupByDay[n] ? groupByDay[n].length : 0;
      });

      //  Add to chart
      ctrl.combinedChartData.series[types[type]] = {
        name: type,
        data: chartData
      };

      // Summary table
      ctrl.summary[type] = _.reduce(data, function(sum, item) {
        var dynamicUserId = item.userId;
        
    	  if(type === 'commits') {
    		  dynamicUserId = item.scmAuthor;
    	  }
        if (moment().endOf('day').diff(moment(item.scmCommitTimestamp), 'days') === 0) sum.lastDay++;
        if (moment().endOf('day').diff(moment(item.scmCommitTimestamp), 'days') < 7)  sum.lastWeek++;
        if (moment().endOf('day').diff(moment(item.scmCommitTimestamp), 'days') < 14) sum.lastFortnight++;


        if (moment().endOf('day').diff(moment(item.scmCommitTimestamp), 'days') === 0 && dynamicUserId) sum.lastDayContributers = _.uniq(sum.lastDayContributers.concat(dynamicUserId));
        if (moment().endOf('day').diff(moment(item.scmCommitTimestamp), 'days') < 7 && dynamicUserId)  sum.lastWeekContributers = _.uniq(sum.lastWeekContributers.concat(dynamicUserId));;
        if (moment().endOf('day').diff(moment(item.scmCommitTimestamp), 'days') < 14 && dynamicUserId) sum.lastFortnightContributers = _.uniq(sum.lastFortnightContributers.concat(dynamicUserId));;

        return sum;
      }, {
        lastDay: 0,
        lastWeek: 0,
        lastFortnight: 0,
        lastDayContributers: [],
        lastWeekContributers: [],
        lastFortnightContributers: []
      });

    }

  }
})();