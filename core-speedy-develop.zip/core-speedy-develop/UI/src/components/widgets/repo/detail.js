(function () {
    'use strict';

    angular
        .module(HygieiaConfig.module)
        .controller('RepoDetailController', RepoDetailController);

    RepoDetailController.$inject = ['$uibModalInstance', 'commits', 'pulls', 'issues', 'deletes', 'checkouts', 'activeUsers', 'DashStatus', 'repoName'];
    function RepoDetailController($uibModalInstance, commits, pulls, issues, deletes, checkouts, activeUsers, DashStatus, repoName) {
        /*jshint validthis:true */
        var ctrl = this;
        ctrl.repoName = repoName;
        ctrl.statuses = DashStatus;
        ctrl.commits = commits;
        ctrl.pulls = pulls;
        ctrl.issues = issues;
        ctrl.deletes = deletes;
        ctrl.checkouts = checkouts;
        ctrl.activeUsers = activeUsers;

    }
})();