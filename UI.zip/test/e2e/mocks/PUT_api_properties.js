module.exports = {
    request: {
        path: '/api/properties',
        method: 'PUT'
    },
    response: {
        data: {}
    }
};