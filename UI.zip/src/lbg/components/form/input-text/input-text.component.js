function InputTextController($scope, $element, $attrs) {
  var ctrl = this;

  ctrl.$onChanges = function() {
    ctrl.placeholder = ctrl.placeholder || ctrl.name;
  };
}

angular.module('LBG.Components').component('lbgInputText', {
  templateUrl: 'lbg/components/form/input-text/input-text.component.html',
  bindings: {
    placeholder: '@',
    name: '@',
    description: '@',
    value: '='
  },
  controller: InputTextController
});