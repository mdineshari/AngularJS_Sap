

function StatusController(HealthService) {
  var ctrl = this;

  ctrl.$onInit = function () {

    console.log('initeddddd')
    HealthService.collectors()
      .then(data => {
        console.log(data)
        this.collectors = data;
      })
  }

}

angular.module('LBG.Components').component('lbgStatus', {
  templateUrl: 'lbg/components/status/status.component.html',
  controller: StatusController
});