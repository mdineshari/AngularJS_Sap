function ChatItemController($scope, $element, $attrs) {
  var ctrl = this;
}

angular.module('LBG.Components').component('lbgChatItem', {
  templateUrl: 'lbg/components/chat/chat-item.component.html',
  bindings: {
    message: '<',
    tell: '='
  },
  controller: ChatItemController
});