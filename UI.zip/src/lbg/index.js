
angular.module('LBG', ['LBG.Components', 'LBG.Services']);

angular.module('LBG.Components', []);
angular.module('LBG.Services', []);

