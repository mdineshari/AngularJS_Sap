'use strict';

angular
  .module('LBG.Services')
  .service('HealthService', healthService);

healthService.$inject = ['$http'];

function healthService($http) {
   this.collectors = function () {
    return $http.get('/api/speedy/health')
      .then(response => response.data);
  };
};