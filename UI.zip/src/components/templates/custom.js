/**
 * Controller for the dashboard route.
 * Render proper template.
 */
(function () {
  'use strict';

  angular
    .module(HygieiaConfig.module)
    .controller('CustomTemplateController', CustomTemplateController);

  CustomTemplateController.$inject = ['$scope', '$window', '$rootScope', '$http', '$q', 'customDashboardData', 'dashboardData', 'userData', '$filter'];

  function CustomTemplateController($scope, $window, $rootScope, $http, $q, customDashboardData, dashboardData, userData, $filter) {
    var ctrl = this,
      widgetHoverText;
    //console.log("akansha in customjs: ", $rootScope.buildTime)
   ctrl.widgetDetails = "";
  // ctrl.widgetTittle = "";
   //ctrl.widget= $rootScope.buildTime;
    /*ga('send', {
      hitType: 'pageview',
      title: 'Team Dashboard',
      location: document.location.hostname
    });*/
    var teamName = $.parseJSON(localStorage.getItem('teamUrlMapData'))[window.location.hostname];
    if(teamName) {
  	  ga('set', 'dimension1', teamName);
    } else {
  	  ga('set', 'dimension1', window.location.hostname);
    }
    ga('set', 'dimension2', localStorage.getItem('currentSpeedyVersion'));
    ga('send', {
        hitType: 'event',
        eventCategory: 'Dashboard',
    	eventAction: 'Dashboard Accessed',
        eventLabel: 'Team Dashboard'
      });
    
    $scope.setWidgetSettingsModal = function (name) {
      _.each(ctrl.schema, function(item){
          if(_.includes(item.widgets, name)) return item.visible = true;
          item.visible = false;
        });
    }

    ctrl.schema = userData.getConfigurationSchema();
    userData.getConfiguration().then(processConfiguration);

    function processConfiguration(response) {

      _.each(response, function (item, key) {
        if (_.isUndefined(ctrl.schema[key]) && key !== 'id') return console.log("item missing from schema: ", key)
      });

      //  Parse objects and arrays into strings
      _.each(ctrl.schema, function (value, key) {
        if (value.type === "object") response[key] = response[key] ? $filter('json')(response[key]) : "{}";
        if (value.type === "array") response[key] = response[key] ? $filter('json')(response[key]) : "[]";
      });

      ctrl.settings = response;
    }

    ctrl.saveWidgetSettings = function () {

        ctrl.successMessage = null;
        ctrl.errorMessage = null;
  
        var payload = {
          id: ctrl.settings.id
        };
  
        //  Parse the data and covert any previously stringified objects back to object
        _.each(ctrl.schema, function (value, key) {
          if (value.type === "string" || value.type === "number") return payload[key] = ctrl.settings[key] || '';
  
          try {
            payload[key] = JSON.parse(ctrl.settings[key]);
          } catch (e) {
            ctrl.errorMessage = "There was an error with field: " + key;
          }
  
        });
  
        // If any errors, don't submit
        if (ctrl.errorMessage) return;
  
        userData.saveConfiguration(payload)
          .then(function (res) {
            var modalElement = $('.modal-settings');
            modalElement.modal('hide');
            var teamName = $.parseJSON(localStorage.getItem('teamUrlMapData'))[window.location.hostname];
            if(teamName) {
          	  ga('set', 'dimension1', teamName);
            } else {
          	  ga('set', 'dimension1', window.location.hostname);
            }
            ga('set', 'dimension2', localStorage.getItem('currentSpeedyVersion'));
            ga('send', {
                hitType: 'event',
                eventCategory: 'Configuration',
                eventAction: 'Update',
                eventLabel: 'Team Dashboard'
              });
            $window.location.reload();
          })
          .catch(function (err) {
            ctrl.errorMessage = "There was an error saving your configuration";
          });
    }

    //  Layout management    
    $http.get('/api/dashboard/hideshow?dashboardId=' + window.dashboardGlobalData.id).then(function (response) {     
        	  ctrl.layout = response.data.widgetMap;
        	  ctrl.layoutSettings= angular.copy(response.data.widgetMap);
        	  ctrl.id = response.data.id;
        	  console.log(ctrl.layout);
  });    
    ctrl.saveHideShow = function () {
	ctrl.editedLayoutData = {
			id : ctrl.id,
	widgetMap: angular.copy(ctrl.layoutSettings)
	}      
    $http.put('/api/dashboard/hideshow?dashboardId=' + window.dashboardGlobalData.id, JSON.stringify(ctrl.editedLayoutData))
      .success(function (data, status, headers, config) {
    	  $http.get('/api/dashboard/hideshow?dashboardId=' + window.dashboardGlobalData.id).then(function (response) {     
    	        	  ctrl.layout = response.data.widgetMap;
    	        	  ctrl.layoutSettings= angular.copy(response.data.widgetMap);
    	        	  ctrl.id = response.data.id;
    	        	  $rootScope.changedLayout = ctrl.layout;
    	  });
      })
      .error(function (data, status, header, config) {
    	
      });
       
      
    };
   

    //  Careful here, using the controller alias used in the html template
    $scope.$watch('template.layout', function (newValue, oldValue) {
      ctrl.showPeopleHeader = ctrl.layout == undefined ? false  : ctrl.layout.col0.improvement.show || ctrl.layout.col0.happiness.show;
      ctrl.showValueHeader = ctrl.layout== undefined ? false  : ctrl.layout.col0.value.show;
      ctrl.showSpeedHeader = ctrl.layout== undefined ? false  : _.find(ctrl.layout.col1, function (widget) {
        return widget.show;
      });
      ctrl.showQualityHeader = ctrl.layout== undefined ? false  : _.find(ctrl.layout.col2, function (widget) {
        return widget.show;
      });
    });

    customDashboardData.fetchHelpers().then(function (response) {
      ctrl.resourceHelpers = response;
    });

    var packIt = function() {
      setTimeout(function(){
        new Packery(document.querySelector('.two .inner'), {
          itemSelector: '.custom-widget',
          gutter: 0
        });
      }, 450);
    }
    var pageLoad = function () {
        ctrl.showRadar = false;
        ctrl.startDate = '';
        ctrl.endDate = '';
        var commonResourseConfig = $rootScope.commonResourseConfig;
        if (commonResourseConfig) {
          ctrl.firstColumnBgColor = commonResourseConfig[0];
          ctrl.secondColumnBgColor = commonResourseConfig[1];
          ctrl.thirdColumnBgColor = commonResourseConfig[2];
          ctrl.fourthColumnBgColor = commonResourseConfig[3];
        }
        fetchProjectDetails();
        widgetHoverText = customDashboardData.fetchWidgetHoverText();
        packIt();
      },

      fetchProjectDetails = function () {
        customDashboardData.fetchProjectDetails().then(function (response) {
          ctrl.projectDetails = response;
          ctrl.projectDetails.name = ctrl.projectDetails.name + " : " +window.dashboardGlobalData.title;
        });
      };

    ctrl.chartModalDialog = function (selectedChart) {
      ctrl.selectedChart = selectedChart;
      ctrl.chartdata = {};
      ctrl.startDate = '';
      ctrl.endDate = '';
      ctrl.isCalendarOpen = false;
      ctrl.isTrendOverDropdownActive = false;
      switch (selectedChart) {
        case 'noOfCheckins':
          var noOfCheckinsOptions = {
            elements: {
              point: {
                radius: 1.3,
                hoverRadius: 1.3
              }
            },
            maintainAspectRatio: false,
            tooltips: {
              enabled: true
            },
            scales: {
              yAxes: [{
                id: 'y-axis',
                type: 'linear',
                display: true,
                position: 'left',
                ticks: {
                  fontSize: 10
                }
              }],
              xAxes: [{
                id: 'x-axis',
                display: true,
                ticks: {
                  fontSize: 10
                },
                gridLines: {
                  display: false
                }
              }]
            }
          };
          ctrl.chartdata = _.assign({}, ctrl.noOfCheckins);
          if (ctrl.chartdata.data) {
            ctrl.chartdata['data']['dialogoptions'] = noOfCheckinsOptions;
          }
          break;
        case 'FlowEfficiency':
          ctrl.isCalendarOpen = false;
          var flowEfficiencyOptions = {
            maintainAspectRatio: false,
            tooltips: {
              enabled: false
            },
            scales: {
              yAxes: [{
                id: 'y-axis',
                type: 'linear',
                display: true,
                position: 'left',
                ticks: {
                  fontSize: 10
                }
              }],
              xAxes: [{
                id: 'x-axis',
                display: true,
                ticks: {
                  fontSize: 10
                },
                gridLines: {
                  display: false
                }
              }]
            }
          }
          ctrl.chartdata = _.assign({}, ctrl.flowEfficiency);
          if (ctrl.chartdata.data) {
            ctrl.chartdata['data']['dialogoptions'] = flowEfficiencyOptions;
          }
          break;

        case 'cfd':
          ctrl.isCalendarOpen = false;
          var cfdDataOptions = {
            responsive: true,
            maintainAspectRatio: false,
            tooltips: {
              enabled: false
            },
            scales: {
              yAxes: [{
                stacked: true,
                ticks: {
                  beginAtZero: true,
                  fontSize: 10
                }
              }],
              xAxes: [{
                stacked: true,
                ticks: {
                  beginAtZero: true,
                  fontSize: 10
                }
              }]
            },
            fontSize: 20,
            legend: {
              display: true,
              position: 'bottom',
              labels: {
                boxWidth: 10,
                fontSize: 14
              }
            }
          };
          ctrl.chartdata = _.assign({}, ctrl.cfdData);
          if (ctrl.chartdata.data) {
            ctrl.chartdata['data']['dialogoptions'] = cfdDataOptions;
          }
          break;

        case 'defectInjectionRate':
          ctrl.isCalendarOpen = false;
          var defectInjectionDataOptions = {
            responsive: true,
            maintainAspectRatio: false,
            tooltips: {
              enabled: false
            },
            scales: {
              yAxes: [{
                stacked: true,
                ticks: {
                  beginAtZero: true,
                  fontSize: 10
                }
              }],
              xAxes: [{
                stacked: true,
                ticks: {
                  beginAtZero: true,
                  fontSize: 10
                }
              }]
            },
            fontSize: 20,
            legend: {
              display: true,
              position: 'bottom',
              labels: {
                boxWidth: 10,
                fontSize: 14
              }
            }
          };
          ctrl.chartdata = _.assign({}, ctrl.cfdData);
          if (ctrl.chartdata.data) {
            ctrl.chartdata['data']['dialogoptions'] = defectInjectionDataOptions;
          }
          break;

        case 'AppDemonstration':
          ctrl.isCalendarOpen = false;
          var appDemonstrationOptions = {
            elements: {
              point: {
                radius: 1.3,
                hoverRadius: 1.3
              }
            },
            maintainAspectRatio: false,
            tooltips: {
              enabled: true
            },
            scales: {
              yAxes: [{
                id: 'y-axis',
                type: 'linear',
                display: true,
                position: 'left',
                ticks: {
                  beginAtZero: true,
                  fontSize: 10,
                  fixedStepSize: 1
                }
              }],
              xAxes: [{
                id: 'x-axis',
                display: true,
                ticks: {
                  fontSize: 12
                },
                gridLines: {
                  display: false
                }
              }]
            }
          };
          ctrl.chartdata = _.assign({}, ctrl.appDemonstration);
          if (ctrl.chartdata['data']) {
            ctrl.chartdata['data']['dialogoptions'] = appDemonstrationOptions;
          }
          break;
        default:
          break;
      }
    };

    ctrl.applyTrendOverDates = function (selectedDates) {
      ctrl.chartdata = {};
      ctrl.startDate = selectedDates && selectedDates.startDate || '';
      ctrl.endDate = selectedDates && selectedDates.endDate || '';
      ctrl.selectedFromSprintList = '';
      ctrl.selectedToSprintList = '';
      switch (ctrl.selectedChart) {
        case 'noOfCheckins':
          ctrl.fetchNoOfCheckins();
          break;
        case 'cfd':
          ctrl.fetchCfdData();
          break;
        case 'defectInjectionRate':
          ctrl.fetchDefectInjectionData();
          break;
        case 'autoPercentage':
          ctrl.fetchTrendOverAutoVsManualTest();
          break;
        case 'functionalTestExecutionTime':
          ctrl.fetchTrendOverFunctionalTestExecutionTime();
          break;
        case 'codeBuildTime':
          ctrl.fetchTrendOverCodeBuildTime();
          break;
        case 'timeToFixBrokenBuild':
          ctrl.fetchTrendOverTimeToFixedBroken();
          break;
        case 'backEndJUnit':
          ctrl.fetchTrendOverBackEndJUnit();
          break;
        case 'frontEndJSUnit':
          ctrl.fetchTrendOverFrontEndJUnit();
          break;
        case 'sprintPredictablity':
          ctrl.fetchAllSprintList();
          ctrl.fetchTrendOverSprintPredictability();
          break;
        case 'commitmentReliability':
          ctrl.fetchAllSprintList();
          ctrl.fetchTrendOverCommitmentReliability();
          break;
        case 'storyDorToDod':
          ctrl.fetchAllSprintListWithoutStatus();
          ctrl.fetchTrendOverStoryLeadTime();
          break;
        case 'storyDodToLive':
          ctrl.fetchAllSprintListWithoutStatus();
          ctrl.fetchTrendOverStoryLiveLeadTime();
          break;
        case 'codeQuality':
            ctrl.fetchTrendOverCodeQuality();
            break;
        default:
          ctrl.isTrendOverDropdownActive = false;
          ctrl.isCalendarOpen = false;
          break;

      }
    }


    ctrl.trendOverChartModal = function () {
      ctrl.chartdata = {};
      ctrl.isTrendOverDropdownActive = false;
      switch (ctrl.selectedChart) {
        case 'noOfCheckins':
          ctrl.chartdata = _.assign({}, ctrl.noOfCheckins);
          if (ctrl.chartdata['data']) {
            ctrl.chartdata['data']['dialogoptions'] = ctrl.chartdata['data']['options'];
          }
          ctrl.startDate = ctrl.chartdata.startDate || '';
          ctrl.endDate = ctrl.chartdata.endDate || '';
          ctrl.isCalendarOpen = false;
          break;
        case 'cfd':
          ctrl.chartdata = _.assign({}, ctrl.cfdData);
          if (ctrl.chartdata['data']) {
            ctrl.chartdata['data']['dialogoptions'] = ctrl.chartdata['data']['options'];
          }
          ctrl.startDate = ctrl.chartdata.startDate || '';
          ctrl.endDate = ctrl.chartdata.endDate || '';
          ctrl.isCalendarOpen = false;
          break;
        case 'defectInjectionRate':
          ctrl.chartdata = _.assign({}, ctrl.defectInjectionData);
          if (ctrl.chartdata['data']) {
            ctrl.chartdata['data']['dialogoptions'] = ctrl.chartdata['data']['options'];
          }
          ctrl.startDate = ctrl.chartdata.startDate || '';
          ctrl.endDate = ctrl.chartdata.endDate || '';
          ctrl.isCalendarOpen = false;
          break;
        case 'autoPercentage':
          ctrl.chartdata = _.assign({}, ctrl.trendOverAutoVsManualTest);
          if (ctrl.chartdata['data']) {
            ctrl.chartdata['data']['dialogoptions'] = ctrl.chartdata['data']['options'];
          }
          ctrl.startDate = ctrl.chartdata.startDate || '';
          ctrl.endDate = ctrl.chartdata.endDate || '';
          ctrl.isCalendarOpen = true;
          break;
        case 'functionalTestExecutionTime':
          ctrl.chartdata = _.assign({}, ctrl.trendOverFunctionalTestExecutionTime);
          if (ctrl.chartdata['data']) {
            ctrl.chartdata['data']['dialogoptions'] = ctrl.chartdata['data']['options'];
          }
          ctrl.startDate = ctrl.chartdata.startDate || '';
          ctrl.endDate = ctrl.chartdata.endDate || '';
          ctrl.isCalendarOpen = true;
          break;
        case 'codeBuildTime':
          ctrl.chartdata = _.assign({}, ctrl.trendOverCodeBuildTime);
          if (ctrl.chartdata['data']) {
            ctrl.chartdata['data']['dialogoptions'] = ctrl.chartdata['data']['options'];
          }
          ctrl.startDate = ctrl.chartdata.startDate || '';
          ctrl.endDate = ctrl.chartdata.endDate || '';
          ctrl.isCalendarOpen = true;
          break;
        case 'timeToFixBrokenBuild':
          ctrl.chartdata = _.assign({}, ctrl.trendOverTimeToFixedBrokenBuild);
          if (ctrl.chartdata['data']) {
            ctrl.chartdata['data']['dialogoptions'] = ctrl.chartdata['data']['options'];
          }
          ctrl.startDate = ctrl.chartdata.startDate || '';
          ctrl.endDate = ctrl.chartdata.endDate || '';
          ctrl.isCalendarOpen = true;
          break;
        case 'codeQuality':
          ctrl.chartdata = _.assign({}, ctrl.trendOverCodeQuality);
          if (ctrl.chartdata['data']) {
            ctrl.chartdata['data']['dialogoptions'] = ctrl.chartdata['data']['options'];
          }
          ctrl.startDate = ctrl.chartdata.startDate || '';
          ctrl.endDate = ctrl.chartdata.endDate || '';
          ctrl.isCalendarOpen = true;
          break;
        case 'backEndJUnit':
          ctrl.chartdata = _.assign({}, ctrl.trendOverBackEndJUnit);
          if (ctrl.chartdata['data']) {
            ctrl.chartdata['data']['dialogoptions'] = ctrl.chartdata['data']['options'];
          }
          ctrl.startDate = ctrl.chartdata.startDate || '';
          ctrl.endDate = ctrl.chartdata.endDate || '';
          ctrl.isCalendarOpen = true;
          break;
        case 'frontEndJSUnit':
          ctrl.chartdata = _.assign({}, ctrl.trendOverFrontEndJUnit);
          if (ctrl.chartdata['data']) {
            ctrl.chartdata['data']['dialogoptions'] = ctrl.chartdata['data']['options'];
          }
          ctrl.startDate = ctrl.chartdata.startDate || '';
          ctrl.endDate = ctrl.chartdata.endDate || '';
          ctrl.isCalendarOpen = true;
          break;
        case 'sprintPredictablity':
          ctrl.isCalendarOpen = false;
          ctrl.isTrendOverDropdownActive = true;
          ctrl.chartdata = _.assign({}, ctrl.trendOverSprintPredictability);
          if (ctrl.chartdata['data']) {
            ctrl.isApplyTrendOverActive = false;
            ctrl.chartdata['data']['dialogoptions'] = ctrl.chartdata['data']['options'];
          }
          if (ctrl.chartdata.fromSprint && ctrl.chartdata.toSprint) {
            ctrl.setFromToSplitList(ctrl.chartdata.fromSprint, ctrl.chartdata.toSprint)
          }
          ctrl.tooltipText = ctrl.chartdata.tooltipText;
          ctrl.paramSprintList = [];
          break;
        case 'commitmentReliability':
          ctrl.isCalendarOpen = false;
          ctrl.isTrendOverDropdownActive = true;
          ctrl.chartdata = _.assign({}, ctrl.trendOverCommitmentReliability);
          if (ctrl.chartdata['data']) {
            ctrl.isApplyTrendOverActive = false;
            ctrl.chartdata['data']['dialogoptions'] = ctrl.chartdata['data']['options'];
          }
          if (ctrl.chartdata.fromSprint && ctrl.chartdata.toSprint) {
            ctrl.setFromToSplitList(ctrl.chartdata.fromSprint, ctrl.chartdata.toSprint)
          }
          ctrl.tooltipText = ctrl.chartdata.tooltipText;
          ctrl.paramSprintList = [];
          break;
        case 'storyDorToDod':
          ctrl.isCalendarOpen = false;
          ctrl.isTrendOverDropdownActive = true;
          ctrl.chartdata = _.assign({}, ctrl.trendOverStoryLeadTime);
          if (ctrl.chartdata['data']) {
            ctrl.isApplyTrendOverActive = false;
            ctrl.chartdata['data']['dialogoptions'] = ctrl.chartdata['data']['options'];
          }
          if (ctrl.chartdata.fromSprint && ctrl.chartdata.toSprint) {
            ctrl.setFromToSplitList(ctrl.chartdata.fromSprint, ctrl.chartdata.toSprint)
          }
          ctrl.tooltipText = ctrl.chartdata.tooltipText;
          ctrl.paramSprintList = [];
          break;
        case 'storyDodToLive':
          ctrl.isCalendarOpen = false;
          ctrl.isTrendOverDropdownActive = true;
          ctrl.chartdata = _.assign({}, ctrl.trendOverStoryLiveLeadTime);
          if (ctrl.chartdata['data']) {
            ctrl.isApplyTrendOverActive = false;
            ctrl.chartdata['data']['dialogoptions'] = ctrl.chartdata['data']['options'];
          }
          if (ctrl.chartdata.fromSprint && ctrl.chartdata.toSprint) {
            ctrl.setFromToSplitList(ctrl.chartdata.fromSprint, ctrl.chartdata.toSprint)
          }
          ctrl.tooltipText = ctrl.chartdata.tooltipText;
          ctrl.paramSprintList = [];
          break;
        default:
          break;
      }
    }

    ctrl.fromToSplitList = function () {
      var fromSprint = ctrl.selectedFromSprintList && ctrl.selectedFromSprintList.split(".");
      var toSprint = ctrl.selectedToSprintList && ctrl.selectedToSprintList.split(".");
      var sprintList = [];
      var fromCounter = fromSprint && parseInt(fromSprint[0]);
      var toCounter = toSprint && parseInt(toSprint[0]);
      if (fromCounter && toCounter && fromCounter >= toCounter) {
        ctrl.errorMessage = 'To sprint must be greater than from sprint';
        ctrl.isApplyTrendOverActive = true;
      } else {
        ctrl.isApplyTrendOverActive = false;
        ctrl.errorMessage = '';
        ctrl.allSprintList.forEach(function (item) {
          var sprint = item.split(".");
          if (fromCounter && toCounter && fromCounter <= toCounter && (parseInt(sprint[0]) >= fromCounter && parseInt(sprint[0]) <= toCounter)) {
            sprintList.push(item)
          }
        }, this);
      }
      ctrl.paramSprintList = sprintList;
    }

    ctrl.setFromToSplitList = function (fromSprint, toSprint) {
      ctrl.allSprintList.forEach(function (item) {
        var sprint = item.split(".");
        if (sprint[1].trim() == fromSprint.trim()) {
          ctrl.selectedFromSprintList = item
        }
        if (sprint[1].trim() === toSprint.trim()) {
          ctrl.selectedToSprintList = item
        }
      }, this);
    }

    $scope.customWidgetClick = function (widgetType) {
      ctrl.chartdata = {};
      ctrl.selectedChart = widgetType;
      ctrl.applyTrendOverDates();
    }

    ctrl.fetchStoryDORtoDOD = function () {
      var route = '/api/jiraMVP/DorToDod?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'storyDorToDod',
          title: 'Definition of Ready (DoR) to Definition of Done (DoD)',
          type: 'text',
          tooltipText: widgetHoverText.storyDorToDod,
          data: (response.storyLeadTime && response.storyLeadTime.value) ? response.storyLeadTime : null
        };
      });
    };

    ctrl.fetchStoryDODtoLive = function () {
      var route = '/api/jiraMVP/DodToLive?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'storyDodToLive',
          title: 'Definition of Done to Live',
          type: 'text',
          tooltipText: widgetHoverText.storyDodToLive,
          data: (response.storyLiveLeadTime && response.storyLiveLeadTime.value) ? response.storyLiveLeadTime : null
        };
      });
    };
    
    ctrl.fetchStoryDorToLive = function () {
        var route = '/api/jiraMVP/DorToLive?dashboardId=' + window.dashboardGlobalData.id;
        return customDashboardData.fetchWidgetDetails(route)
        .then(function (response) {
          return {
            name: 'storyDorToLive',
            title: 'Definition of Ready to Live',
            type: 'text',
            tooltipText: widgetHoverText.storyDorToLive,
            data: (response.storyLeadLiveTime && response.storyLeadLiveTime.value) ? response.storyLeadLiveTime : null
          };
        });
      };
      
    ctrl.fetchdorToLiveProductivity = function() {
          var route = '/api/jiraMVP/productiveStates?dashboardId=' + window.dashboardGlobalData.id;
          return customDashboardData.fetchWidgetDetails(route).then(function(response) {
              return {
                  name: 'dorToLiveProductivity',
                  title: 'Average Time Spent in Productive States',
                  type: 'text',
                  tooltipText: widgetHoverText.dorToLiveProductivity,
                  data: (response.averageTimeSpent && response.averageTimeSpent.value) ? response.averageTimeSpent : null
              };
           });
      }; 
      
      ctrl.fetchReductionInWaste = function() {
          var route = '/api/jiraMVP/wasteStates?dashboardId=' + window.dashboardGlobalData.id;
          return customDashboardData.fetchWidgetDetails(route).then(function(response) {
              return {
                  name: 'reductionInWaste',
                  title: 'Average Time Spent in Waste States',
                  type: 'text',
                  tooltipText: widgetHoverText.reductionInWaste,
                  data: (response.averageTimeSpent && response.averageTimeSpent.value) ? response.averageTimeSpent : null
              };
           });
      }; 

    ctrl.fetchStoryLeadTime = function () {
      var route = '/api/jiraMVP/leadTime';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'storyLeadTime',
          title: 'Lead Time',
          type: 'text',
          tooltipText: widgetHoverText.storyLeadTime,
          data: (response.storyLeadTime && response.storyLeadTime.value) ? response.storyLeadTime : null
        };
      });
    };

    ctrl.fetchStoryBacklogtoDOR = function () {
      var route = '/api/jiraMVP/backlogToDor';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'storyBacklogToDor',
          title: 'Backlog to Definition of Ready (DoR)',
          type: 'text',
          tooltipText: widgetHoverText.storyBacklogToDor,
          data: (response.storyLeadTime && response.storyLeadTime.value) ? response.storyLeadTime : null
        };
      });
    };

    ctrl.fetchDefectInjectionRate = function () {
      var route = '/api/jiraMVP/defectinjectionrate?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'defectInjectionRate',
          title: 'Defect Flow',
          type: 'text',
          tooltipText: widgetHoverText.defectInjectionRate,
          data: (response.defectInjectionRate && response.defectInjectionRate.value) ? response.defectInjectionRate : null,
          openIssues: response.openIssues,
          closeIssues: response.closedIssues,
          defectTimeMap: response.defectTimeMap ? response.defectTimeMap : null
        };
      });
    };

    ctrl.fetchDefectInjectionRatePostlive = function () {
      var route = '/api/jiraMVP/defectinjectionratepostlive';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'defectInjectionRatePostLive',
          title: 'Defect Injection Rate Post Live',
          type: 'text',
          tooltipText: widgetHoverText.defectInjectionRatePostLive,
          data: (response.defectInjectionRatePostLive && response.defectInjectionRatePostLive.value) ? response.defectInjectionRatePostLive : null
        };
      });
    };

    ctrl.fetchDeploymentFrequency = function () {
      var route = '/api/excel/deployFrequency';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData;

        if (response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            options: {
              maintainAspectRatio: false,
              tooltips: {
                enabled: false
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    fontSize: 8
                  }
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 8
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: ctrl.secondColumnBgColor,
              borderColor: '#66666654',
              borderWidth: "0.8",
            }
          };
        }
        return {
          name: 'deploymentFrequency',
          title: 'Deployment Frequency',
          type: 'line',
          tooltipText: widgetHoverText.deploymentFrequency,
          data: graphData
        };
      });
    };

    ctrl.fetchNoOfCheckins = function () {
      var route = '/api/ed/commit?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData;

        if (response && response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            options: {
              elements: {
                point: {
                  radius: 1.3,
                  hoverRadius: 1.3
                }
              },
              maintainAspectRatio: false,
              tooltips: {
                enabled: true,
                titleFontSize: 7,
                bodyFontSize: 7
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    fontSize: 8
                  }
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 8
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: ctrl.secondColumnBgColor,
              borderColor: '#66666654',
              borderWidth: "0.8",
            }
          };
        }
        var noOfCheckins = {
          name: 'noOfCheckins',
          title: 'Number of Check-in Per Day',
          type: 'line',
          tooltipText: widgetHoverText.noOfCheckins,
          data: graphData
        };
        ctrl.noOfCheckins = noOfCheckins;
        ctrl.trendOverChartModal()
        return noOfCheckins;
      });
    };

    ctrl.fetchFlowEfficiency = function () {
      var route = '/api/excel/flowefficiency';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData;

        if (response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            options: {
              maintainAspectRatio: false,
              tooltips: {
                enabled: false
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    fontSize: 8
                  }
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 8
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: 'rgba(0,0,0,0)',
              borderWidth: "0.8",
            }
          };
        }
        var flowEfficiency = {
          name: 'flowEfficiency',
          title: 'Flow Efficiency',
          type: 'line',
          tooltipText: widgetHoverText.flowEfficiency,
          data: graphData
        };
        ctrl.flowEfficiency = flowEfficiency;
        return flowEfficiency;
      });
    };

    ctrl.fetchCfdData = function () {
      var route = '/api/jiraMVP/cfddetails?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData;

        if (response && response.countList) {
          graphData = {
            data: response.countList,
            labels: response.monthList,
            series: response.statusList,
            colors: [
              ctrl.secondColumnBgColor,
              '#f4424e',
              '#2b3547',
              '#1194db',
              '#24513f',
              '#09f9d9'
            ],
            options: {
              responsive: true,
              maintainAspectRatio: false,
              tooltips: {
                enabled: true
              },
              scales: {
                yAxes: [{
                  stacked: true,
                  ticks: {
                    beginAtZero: true,
                    fontSize: 8
                  }
                }],
                xAxes: [{
                  stacked: true,
                  ticks: {
                    beginAtZero: true,
                    fontSize: 8
                  }
                }]
              },
              fontSize: 8,
              legend: {
                display: true,
                position: 'bottom',
                labels: {
                  boxWidth: 3,
                  fontSize: 8
                }
              }
            }
          };
        }
        var cfdData = {
          name: 'cfd',
          title: 'Cumulative Flow Diagram',
          type: 'line',
          tooltipText: widgetHoverText.cfd,
          data: graphData
        };

        ctrl.cfdData = cfdData;
        ctrl.trendOverChartModal();
        return cfdData;
      });
    };

    ctrl.fetchDefectInjectionData = function () {
      var route = '/api/jiraMVP/defectinjectionrate?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData;
        if (response && response.defectTimeMap && Object.keys(response.defectTimeMap).length > 0) {
          var countList = [];
          Object.keys(response.defectTimeMap).map(function(dat,ele) {
            countList.push(response.defectTimeMap[dat]);
          });
          graphData = {
            data: countList,
            labels: Object.keys(response.defectTimeMap),
            series: response.statusList,
            options: {
              responsive: true,
              maintainAspectRatio: false,
              tooltips: {
                enabled: true
              },
              scales: {
                yAxes: [{
                  stacked: true,
                  ticks: {
                    beginAtZero: true,
                    fontSize: 8
                  }
                }],
                xAxes: [{
                  stacked: true,
                  ticks: {
                    beginAtZero: true,
                    fontSize: 8
                  }
                }]
              },
              fontSize: 8,
              legend: {
                display: false,
                position: 'bottom',
                labels: {
                  boxWidth: 3,
                  fontSize: 8
                }
              }
            },
            datasetOverride: {
              backgroundColor: '#2d9b4f',
              hoverBackgroundColor: ctrl.firstColumnBgColor,
              borderColor: '#709dca'
            }
          };
        }
        var defectInjectionData = {
          name: 'defectInjectionRate',
          title: 'Defect Flow Diagram',
          type: 'bar',
          tooltipText: widgetHoverText.cfd,
          data: graphData
        };

        ctrl.defectInjectionData = defectInjectionData;
        ctrl.trendOverChartModal();
        return defectInjectionData;
      });
    };

    ctrl.fetchEnvCreationTime = function () {
      var route = '/api/ed/citime?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'envCreationTime',
          title: 'Time to Create a New Environment',
          type: 'text',
          tooltipText: widgetHoverText.envCreationTime,
          data: (response.envCreationTime && response.envCreationTime.value) ? response.envCreationTime : null
        };
      });
    };

    ctrl.fetchHappinessIndex = function () {
      var route = '/api/excel/happinessindex?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData;
        if (response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            options: {
              scales: {
                xAxes: [{
                  display: false
                }],
                yAxes: [{
                  ticks: {
                    beginAtZero: true
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: '#2d9b4f',
              hoverBackgroundColor: ctrl.firstColumnBgColor,
              borderColor: '#709dca'
            }
          };
        }
        return {
          name: 'happinessIndex',
          title: 'Happiness Index',
          type: 'bar',
          tooltipText: widgetHoverText.happinessIndex,
          data: graphData
        };
      });
    };

    ctrl.fetchAppDemonstration = function () {
      var route = '/api/excel/appdemonstration?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData;

        if (response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            colors: [
              '#f8b2b5'
            ],
            options: {
              elements: {
                point: {
                  radius: 1.3,
                  hoverRadius: 1.3
                }
              },
              maintainAspectRatio: false,
              tooltips: {
                enabled: false
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    fontSize: 8
                  }
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 8
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: ctrl.thirdColumnBgColor,
              borderColor: '#66666654',
              borderWidth: "0.8",
            }
          };
        }
        var appDemonstration = {
          name: 'appDemonstration',
          title: 'Completed Stories are Demonstrated to Product Owner',
          type: 'line',
          tooltipText: widgetHoverText.appDemonstration,
          data: graphData
        };
        ctrl.appDemonstration = appDemonstration;
        return appDemonstration;
      });
    };

    ctrl.fetchSprintPredictability = function () {
      var route = '/api/jiraMVP/sprintpredictability?dashboardId=' + window.dashboardGlobalData.id;

      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData,
          sprintPredictablity;

        if (response && response.sprintPredictablity && response.sprintPredictablity.value) {
          sprintPredictablity = response.sprintPredictablity.value;
        }

        if (sprintPredictablity) {
          var fillSprintPredictablityPercentage = parseInt(sprintPredictablity) > 100 ? 100 : sprintPredictablity
          graphData = {
            data: [sprintPredictablity, 100 - fillSprintPredictablityPercentage],
            symbol: response.sprintPredictablity.unit,
            colors: [
              ctrl.secondColumnBgColor,
              '#e2e2e2'
            ],
            options: {
              legend: {
                display: false
              },
              tooltips: {
                enabled: true,
                titleFontSize: 7,
                bodyFontSize: 7
              },
              cutoutPercentage: 70
            }
          };
        }
        return {
          name: 'sprintPredictablity',
          title: 'Sprint Predictability',
          type: 'doughnut',
          tooltipText: widgetHoverText.sprintPredictablity,
          data: graphData
        };
      });
    };

    ctrl.fetchReleaseDeployTime = function () {
      var route = '/api/ed/citime?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'releaseDeployTime',
          title: 'Release and Deploy Time',
          type: 'text',
          tooltipText: widgetHoverText.releaseDeployTime,
          data: (response.relAndDeployTime && response.relAndDeployTime.value) ? response.relAndDeployTime : null
        };
      });
    };

    ctrl.fetchAutoVsManualTest = function () {
      var route = '/api/excel/autovsmanualtest?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData,
          autoPercentage;

        if (response && response.autoPercentage && response.autoPercentage.value) {
          autoPercentage = response.autoPercentage.value;
        }

        if (autoPercentage) {
          var fillAutoPercentage = parseInt(autoPercentage) > 100 ? 100 : autoPercentage
          graphData = {
            data: [autoPercentage, 100 - fillAutoPercentage],
            labels: ['Automated', 'Manual'],
            colors: [
              ctrl.thirdColumnBgColor,
              '#e2e2e2'
            ],
            options: {
              tooltips: {
                enabled: false
              }
            }
          };
        }
        var autoVsManualTest = {
          name: 'autoPercentage',
          title: 'Automated Test %',
          type: 'pie',
          tooltipText: widgetHoverText.autoPercentage,
          data: graphData
        };

        ctrl.autoVsManualTest = autoVsManualTest;
        return autoVsManualTest;
      });
    };

    ctrl.fetchCodeQuality = function () {
      var route = '/api/mdquality/static-analysis?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData,
          qualityGrade,
          colors = [
            '#e2e2e2',
            '#e2e2e2',
            '#e2e2e2',
            '#e2e2e2',
            '#e2e2e2'
          ];

        qualityGrade = (response && response.qualityGrade) ? response.qualityGrade : null;
        //qualityGrade = 'A';

        switch (qualityGrade) {
          case 'A':
            qualityGrade = 5;
            break;
          case 'B':
            qualityGrade = 4;
            break;
          case 'C':
            qualityGrade = 3;
            break;
          case 'D':
            qualityGrade = 2;
            break;
          case 'E':
            qualityGrade = 1;
            break;
        };

        colors[qualityGrade - 1] = ctrl.thirdColumnBgColor;

        if (qualityGrade) {
          graphData = {
            data: [1, 2, 3, 4, 5],
            labels: ['E', 'D', 'C', 'B', 'A'],
            colors: colors,
            options: {
              maintainAspectRatio: false,
              tooltips: {
                enabled: true,
                callbacks: {
                  label: function () {
                    return "";
                  }
                }
              },
              scales: {
                yAxes: [{
                  display: false,
                  gridLines: {
                    display: false
                  }
                }],
                xAxes: [{
                  display: true,
                  ticks: {
                    fontSize: 7
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            }
          };
        }
        return {
          name: 'codeQuality',
          title: 'Code Quality',
          type: 'bar',
          tooltipText: widgetHoverText.codeQuality,
          data: qualityGrade !== 'NA' ? graphData : undefined
        };
      });
    };

    ctrl.fetchJUnitCoverage = function () {
      var route = '/api/mdquality/static-analysis?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var data,
          coveragePercentage,
          jscoveragePercentage;

        if (response && response.coveragePercentage && response.coveragePercentage.value) {
          coveragePercentage = response.coveragePercentage;
        }

        if (response && response.jscoveragePercentage && response.jscoveragePercentage.value) {
          jscoveragePercentage = response.jscoveragePercentage;
        }

        data = [{
            name: 'backEndJUnit',
            title: 'Back End Code Coverage',
            data: coveragePercentage ? coveragePercentage : null
          },
          {
            name: 'frontEndJSUnit',
            title: 'Front End Code Coverage',
            data: jscoveragePercentage ? jscoveragePercentage : null
          }
        ];

        
        var coveragePercentage = {
        		name: 'coveragePercentage',
                title: 'Coverage',
                type: 'multipleTextWidget',
                tooltipText: widgetHoverText.coveragePercentage,
                width: (100 / data.length) + '%',
                data: data
              };

              ctrl.coveragePercentage = coveragePercentage;
              return coveragePercentage;
        
        
      });
    };

    ctrl.fetchPassPercent = function () {
      var route = '/api/mdquality/static-analysis?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var data,
          jUnitSuccessPercentage,
          jsJUnitSuccessPercentage;

        if (response && response.jUnitSuccessPercentage && response.jUnitSuccessPercentage.value) {
          jUnitSuccessPercentage = response.jUnitSuccessPercentage;
        }

        if (response && response.jsJUnitSuccessPercentage && response.jsJUnitSuccessPercentage.value) {
          jsJUnitSuccessPercentage = response.jsJUnitSuccessPercentage;
        }

        data = [{
            title: 'Pass %',
            data: jUnitSuccessPercentage ? jUnitSuccessPercentage : null
          },
          {
            title: 'JS Pass %',
            data: jsJUnitSuccessPercentage ? jsJUnitSuccessPercentage : null
          }
        ];

        return {
          name: 'passPercentage',
          title: 'Pass %',
          type: 'multipleTextWidget',
          tooltipText: widgetHoverText.passPercentage,
          width: (100 / data.length) + '%',
          data: data
        };
      });
    };

    ctrl.fetchImprovement = function () {
      var route = '/api/excel/improvement?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'improvement',
          title: 'Improvement',
          type: 'status',
          tooltipText: widgetHoverText.improvement,
          data: (response && response.response !== undefined) ? response : null
        };
      });
    };

    ctrl.fetchCITime = function () {
      var fetchFixTime = function () {
          var route = '/api/ed/citime?dashboardId=' + window.dashboardGlobalData.id;
          return customDashboardData.fetchWidgetDetails(route)
          .then(function (response) {
        	  
            return (response.fixTimeSVU && response.fixTimeSVU.value) ? response.fixTimeSVU : null;
          });
        },

        fetchBuildTime = function () {
          var route = '/api/ed/citime?dashboardId=' + window.dashboardGlobalData.id;
          return customDashboardData.fetchWidgetDetails(route)
          .then(function (response) {
            return (response.buildTimeSVU && response.buildTimeSVU.value) ? response.buildTimeSVU : null;
          });
        },

        fetchSumTestExecution = function () {
          var route = '/api/excel/autovsmanualtest?dashboardId=' + window.dashboardGlobalData.id;
          return customDashboardData.fetchWidgetDetails(route)
          .then(function (response) {
            return (response.sumTestExecution && response.sumTestExecution.value) ? response.sumTestExecution : null;
          });
        },

        fetchBuildTimeMap = function () {
            var route = '/api/ed/citime?dashboardId=' + window.dashboardGlobalData.id;
            return customDashboardData.fetchWidgetDetails(route)
            .then(function (response) {
            	//console.log("akansha response: ", response.buildTimeMap)
//            	var result = Object.keys(response.buildTimeMap).map(function(key) {
//            		  return [key, response.buildTimeMap[key]];
//            	});
//            	console.log("akansh result :",result)
              return response.buildTimeMap;
            });
          },
          
          fetchBuildFixTimeMap = function () {
              var route = '/api/ed/citime?dashboardId=' + window.dashboardGlobalData.id;
              
              return customDashboardData.fetchWidgetDetails(route)
              .then(function (response) {
              	console.log("akansha response: ", response)
//              	var result = Object.keys(response.buildTimeMap).map(function(key) {
//              		  return [key, response.buildTimeMap[key]];
//              	});
//              	console.log("akansh result :",result)
                return response.buildFixTimeMap;
              });
            },
        //console.log("akansha fetchBuildTimeMap: ",fetchBuildTimeMap())  
        deferred = $q.defer();

      $q.all([

        fetchFixTime(),
        fetchBuildTime(),
        fetchSumTestExecution(),
        fetchBuildTimeMap(),
        fetchBuildFixTimeMap()

      ]).then(function (response) {
    	  console.log("akansha q response: ", response)
        var data = [{
              name: 'timeToFixBrokenBuild',
              title: 'Time to fix a Broken Build',
              data: response[0] ? response[0] : null ,
              buildTimeMap: response[4] ? response[4] : null
            },
            {
              name: 'codeBuildTime',
              title: 'Code Build Time',
              data: response[1] ? response[1] : null ,
              buildTimeMap: response[3] ? response[3] : null
            },
            {
              name: 'functionalTestExecutionTime',
              title: 'Functional Test Execution Time',
              data: response[2] ? response[2] : null ,
                      buildTimeMap:  null

            }
          ],
          widgetData = {
            name: 'citime',
            title: 'CI Time',
            type: 'multipleTextWidget',
            tooltipText: widgetHoverText.citime,
            width: (100 / data.length) + '%',
            data: data
          };
        deferred.resolve(widgetData);
      });

      return deferred.promise;
    };

    ctrl.showMaturityRadar = function (event) {
      var button = $('.radar-button');
      ctrl.showRadar = !ctrl.showRadar;
      if (ctrl.showRadar) {
        button.text('Team Dashboard');
      } else {
        button.text('Maturity Radar');
        d3.select(".maturity-radar").select("svg").remove();
      }
    };


    ctrl.commitmentReliability = function () {
      var route = '/api/jiraMVP/commitmentReliability?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'commitmentReliability',
          title: 'Commitment Reliability',
          type: 'text',
          tooltipText: widgetHoverText.commitmentReliability,
          data: (response.commitmentReliability && response.commitmentReliability.value) ? response.commitmentReliability : null
        };
      });
    };

    ctrl.fetchRisks = function () {
      var route = '/api/jiraMVP/risks';

      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'risks',
          title: 'Risks',
          type: 'list',
          tooltipText: widgetHoverText.risks,
          data: response.dataCount || null
        };
      });
    };

    ctrl.fetchTopIssues = function () {
      var route = '/api/jiraMVP/topIssues';

      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'topIssues',
          title: 'Top Issues',
          type: 'list',
          tooltipText: widgetHoverText.topIssues,
          data: response.dataCount || null
        };
      });
    };

    ctrl.fetchIssues = function () {
      var route = '/api/jiraMVP/issues';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'issues',
          title: 'Issues',
          type: 'list',
          tooltipText: widgetHoverText.issues,
          data: response.dataCount || null
        };
      });
    };

    ctrl.fetchAgingIssue = function () {
      var route = '/api/jiraMVP/agingIssue';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'agingIssue',
          title: 'Aging Issue',
          type: 'text',
          tooltipText: widgetHoverText.agingIssue,
          data: (response.agingIssueLevel && response.agingIssueLevel.value) ? response.agingIssueLevel : null
          //data: '{"agingIssueLevel":{"symbol":"","value":"65","unit":"%"}}'
        };
      });
    };

    ctrl.fetchTechDebt = function () {
      var route = '/api/jiraMVP/techDebt?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'techDebt',
          title: 'Tech Debt',
          type: 'text',
          tooltipText: widgetHoverText.techDebt,
          data: (response.techDebt && response.techDebt.value) ? response.techDebt : null
        };
      });
    };

    ctrl.fetchSonarTechDebt = function () {
      var route = '/api/mdquality/static-analysis?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'techDebt',
          title: 'Sonar Tech Debt',
          type: 'text',
          tooltipText: widgetHoverText.sonarTechDebt,
          data: (response.techDebt && response.techDebt.value) ? response.techDebt : null
        };
      });
    };

    /* ctrl.fetchAssignValueMetric = function() {
         var route = '/api/jiraMVP/assignedMetrics';
         return customDashboardData.fetchWidgetDetails(route)
         .then(function(response) {
             var graphData,
             assignedValuePercentage;
             
             if(response && response.assignedValuePercentage && response.assignedValuePercentage.value) {
             	assignedValuePercentage = response.assignedValuePercentage;
             }

             if(assignedValuePercentage) {
                 var fillAssignedValuePercentage = parseInt(assignedValuePercentage.value) > 100 ? 100 : assignedValuePercentage.value
                 graphData = {
                     data: [assignedValuePercentage.value, 100-fillAssignedValuePercentage],
                     symbol:"%",
                     colors: [
                         '#2779bc',
                         '#e2e2e2'
                     ],
                     options: {
                         legend: {
                             display: false
                         },
                         tooltips: {
                             enabled: false
                         },
                         cutoutPercentage: 70
                     }
                 };
            }
             return {
                 name: 'assignedValuePercentage',
                 title: 'Assign Value Metrics',
                 type: 'doughnut',
                 tooltipText: widgetHoverText.assignedValuePercentage,
                 data: graphData
             };
          });
     };           
     */
    ctrl.fetchAssignValueMetric = function () {
      var route = '/api/jiraMVP/assignedMetrics?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'assignedValuePercentage',
          title: 'Assign Value Metrics',
          type: 'text',
          tooltipText: widgetHoverText.assignedValuePercentage,
          data: (response.assignedValuePercentage && response.assignedValuePercentage.value) ? response.assignedValuePercentage : null
        };
      });
    };

    /*            ctrl.fetchBacklogHealth = function() {
                    var route = '/api/jiraMVP/backlogHealth';
                    return customDashboardData.fetchWidgetDetails(route)
                    .then(function(response) {
                        var graphData,
                        backlogHealthPercentage;
                        
                        if(response && response.backlogHealthPercentage && response.backlogHealthPercentage.value) {
                        	backlogHealthPercentage = response.backlogHealthPercentage;
                        }
                        if(backlogHealthPercentage) {
                            var color  = ctrl.resourceHelpers && ctrl.resourceHelpers.backlogHealthBackgroundColor && ctrl.resourceHelpers.backlogHealthBackgroundColor[colorType]                       
                            var fillBacklogHealthPercentage = parseInt(backlogHealthPercentage.value) > 100 ? 100 : backlogHealthPercentage.value
                            graphData = {
                                data: [backlogHealthPercentage.value, 100-fillBacklogHealthPercentage],
                                symbol:"%",
                                colors: [
                                    color,
                                    '#e2e2e2'
                                ],
                                options: {
                                    legend: {
                                        display: false
                                    },
                                    tooltips: {
                                        enabled: false
                                    },
                                    cutoutPercentage: 70
                                }
                            };
                       }
                        return {
                            name: 'backlogHealthPercentage',
                            title:'Backlog Health',
                            type: 'doughnut',
                            tooltipText: widgetHoverText.backlogHealthPercentage,
                            data: graphData
                        };
                     });
                };  */
    ctrl.fetchBacklogHealth = function () {
      var route = '/api/jiraMVP/backlogHealth?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'backlogHealthPercentage',
          title: 'Backlog Health',
          type: 'text',
          tooltipText: widgetHoverText.backlogHealthPercentage,
          data: (response.backlogHealthPercentage && response.backlogHealthPercentage.value) ? response.backlogHealthPercentage : null
        };
      });
    };

    ctrl.fetchAssignValueTrend = function () {
      var route = '/api/jiraMVP/assignedMetricsTrend';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData;

        if (response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            options: {
              maintainAspectRatio: false,
              tooltips: {
                enabled: false
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    fontSize: 4
                  }
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 4
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: ctrl.secondColumnBgColor,
              borderColor: '#66666654',
              borderWidth: "0.8",
            }
          };
        }
        return {
          name: 'assignmentTrend',
          title: 'Trend for Assign Value Metrics',
          type: 'line',
          tooltipText: widgetHoverText.assignmentValueTrend,
          data: graphData
        };
      });
    };

    ctrl.fetchTrendOverAutoVsManualTest = function () {
      var route = '/api/trend/automation?startDate=' + ctrl.startDate + '&endDate=' + ctrl.endDate + '&dashboardId=' + window.dashboardGlobalData.id+'';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData;

        if (response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            options: {
              maintainAspectRatio: false,
              tooltips: {
                enabled: true
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    fontSize: 10,
                    callback: function (label, index, labels) {
                      return parseFloat(Math.round(label * 100) / 100).toFixed(2) + (response.unit || '')
                    }
                  },
                  scaleLabel: {
                    display: true,
                    labelString: 'value in' + (response.unit || '')
                  },
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 10
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: ctrl.secondColumnBgColor,
              borderColor: '#66666654',
              borderWidth: "0.8",
            }
          };
        }

        var trendOverAutoVsManualTest = {
          name: 'TrendOverAutomation',
          title: 'Trend over automation',
          type: 'line',
          tooltipText: widgetHoverText.trendOverAutoVsManual,
          data: graphData,
          startDate: response.startDate,
          endDate: response.endDate
        };

        ctrl.trendOverAutoVsManualTest = trendOverAutoVsManualTest;
        ctrl.trendOverChartModal();
        return trendOverAutoVsManualTest;
      });
    };

    ctrl.fetchTrendOverFunctionalTestExecutionTime = function () {
      var route = '/api/trend/functionaltest?startDate=' + ctrl.startDate + '&endDate=' + ctrl.endDate + '&dashboardId=' + window.dashboardGlobalData.id+'';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData;

        if (response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            options: {
              maintainAspectRatio: false,
              tooltips: {
                enabled: true
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    fontSize: 10,
                    callback: function (label, index, labels) {
                      return parseFloat(Math.round(label * 100) / 100).toFixed(2) + (response.unit || '')
                    }
                  },
                  scaleLabel: {
                    display: true,
                    labelString: 'value in' + (response.unit || '')
                  },
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 10
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: ctrl.secondColumnBgColor,
              borderColor: '#66666654',
              borderWidth: "0.8",
            }
          };
        }

        var trendOverFunctionalTestExecutionTime = {
          name: 'trendOverFunctionalTestExecutionTime',
          title: 'Trend over functional test execution',
          type: 'line',
          tooltipText: widgetHoverText.trendOverFunctionalTestExecutionTime,
          data: graphData,
          startDate: response.startDate,
          endDate: response.endDate
        };

        ctrl.trendOverFunctionalTestExecutionTime = trendOverFunctionalTestExecutionTime;
        ctrl.trendOverChartModal();
        return trendOverFunctionalTestExecutionTime;
      });
    };

    ctrl.fetchTrendOverCodeBuildTime = function () {
      var route = '/api/trend/buildTimeTrend?startDate=' + ctrl.startDate + '&endDate=' + ctrl.endDate + '&dashboardId=' + window.dashboardGlobalData.id+'';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData;

        if (response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            options: {
              maintainAspectRatio: false,
              tooltips: {
                enabled: true
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    fontSize: 10,
                    callback: function (label, index, labels) {
                      return parseFloat(Math.round(label * 100) / 100).toFixed(2) + (response.unit || '')
                    }
                  },
                  scaleLabel: {
                    display: true,
                    labelString: 'value in' + (response.unit || '')
                  },
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 10
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: ctrl.secondColumnBgColor,
              borderColor: '#66666654',
              borderWidth: "0.8",
            }
          };
        }

        var trendOverCodeBuildTime = {
          name: 'trendOverCodeBuildTime',
          title: 'Trend over Code Build Time',
          type: 'line',
          tooltipText: widgetHoverText.trendOverCodeBuildTime,
          data: graphData,
          startDate: response.startDate,
          endDate: response.endDate
        };

        ctrl.trendOverCodeBuildTime = trendOverCodeBuildTime;
        ctrl.trendOverChartModal();
        return trendOverCodeBuildTime;
      });
    };

    ctrl.fetchTrendOverTimeToFixedBroken = function () {
      var route = '/api/trend/fixTimeTrend?startDate=' + ctrl.startDate + '&endDate=' + ctrl.endDate + '&dashboardId=' + window.dashboardGlobalData.id+'';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData;

        if (response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            options: {
              maintainAspectRatio: false,
              tooltips: {
                enabled: true
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    fontSize: 10,
                    callback: function (label, index, labels) {
                      return parseFloat(Math.round(label * 100) / 100).toFixed(2) + (response.unit || '')
                    }
                  },
                  scaleLabel: {
                    display: true,
                    labelString: 'value in' + (response.unit || '')
                  },
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 10
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: ctrl.secondColumnBgColor,
              borderColor: '#66666654',
              borderWidth: "0.8",
            }
          };
        }

        var trendOverTimeToFixedBrokenBuild = {
          name: 'trendOverTimeToFixedBrokenBuild',
          title: 'Trend over time to fixed broken build',
          type: 'line',
          tooltipText: widgetHoverText.trendOverTimeToFixedBrokenBuild,
          data: graphData,
          startDate: response.startDate,
          endDate: response.endDate
        };

        ctrl.trendOverTimeToFixedBrokenBuild = trendOverTimeToFixedBrokenBuild;
        ctrl.trendOverChartModal();
        return trendOverTimeToFixedBrokenBuild;
      });
    };

    ctrl.fetchTrendOverCodeQuality = function () {
      var route = '/api/trend/codequalitytrend?startDate=' + ctrl.startDate + '&endDate=' + ctrl.endDate + '&dashboardId=' + window.dashboardGlobalData.id+'';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData;
        if (response.data && response.data.length) {
          var data = [];
          var unique = {};
          var distinct = [];
          var gradeItem = ["E", "D", "C", "B", "A"];
          response.data.forEach(function (item) {
            if (!unique[item]) {
              distinct.push(item);
              unique[item] = true;
            }
            data.push(gradeItem.indexOf(item));
          })

          graphData = {
            data: data,
            labels: response.labels,
            options: {
              maintainAspectRatio: false,
              tooltips: {
                enabled: false
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    beginAtZero: true,
                    min: 0,
                    stepSize: 1,
                    max: 4,
                    callback: function (value, index, values) {
                      return ["A", "B", "C", "D", "E"][index];
                    },
                    autoSkip: true,
                    maxTicksLimit: data.length
                  },
                  scaleLabel: {
                    display: true,
                    labelString: 'value in ' + (response.unit || '')
                  },
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 10
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: ctrl.secondColumnBgColor,
              borderColor: '#66666654',
              borderWidth: "0.8",
            }
          };
        }

        var trendOverCodeQuality = {
          name: 'trendOverCodeQuality',
          title: 'Trend over Code quality',
          type: 'line',
          tooltipText: widgetHoverText.trendOverCodeQuality,
          data: graphData,
          startDate: response.startDate || '',
          endDate: response.endDate || ''
        };

        ctrl.trendOverCodeQuality = trendOverCodeQuality;
        ctrl.trendOverChartModal();
        return trendOverCodeQuality;
      });
    };

    ctrl.fetchTrendOverBackEndJUnit = function () {
      var route = '/api/trend/backendjunittrend?startDate=' + ctrl.startDate + '&endDate=' + ctrl.endDate + '&dashboardId=' + window.dashboardGlobalData.id+'';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData;

        if (response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            options: {
              maintainAspectRatio: false,
              tooltips: {
                enabled: true
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    fontSize: 10,
                    callback: function (label, index, labels) {
                      return parseFloat(Math.round(label * 100) / 100).toFixed(2) + (response.unit || '')
                    }
                  },
                  scaleLabel: {
                    display: true,
                    labelString: 'value in' + (response.unit || '')
                  },
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 10
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: ctrl.secondColumnBgColor,
              borderColor: '#66666654',
              borderWidth: "0.8",
            }
          };
        }

        var trendOverBackEndJUnit = {
          name: 'trendOverBackEndJUnit',
          title: 'Trend over back end JUnit',
          type: 'line',
          tooltipText: widgetHoverText.trendOverBackEndJUnit,
          data: graphData,
          startDate: response.startDate,
          endDate: response.endDate
        };

        ctrl.trendOverBackEndJUnit = trendOverBackEndJUnit;
        ctrl.trendOverChartModal();
        return trendOverBackEndJUnit;
      });
    };

    ctrl.fetchTrendOverFrontEndJUnit = function () {
      var route = '/api/trend/frontendjunittrend?startDate=' + ctrl.startDate + '&endDate=' + ctrl.endDate + '&dashboardId=' + window.dashboardGlobalData.id+'';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData;

        if (response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            options: {
              maintainAspectRatio: false,
              tooltips: {
                enabled: true
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    fontSize: 10,
                    callback: function (label, index, labels) {
                      return parseFloat(Math.round(label * 100) / 100).toFixed(2) + (response.unit || '')
                    }
                  },
                  scaleLabel: {
                    display: true,
                    labelString: 'value in' + (response.unit || '')
                  },
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 10
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: ctrl.secondColumnBgColor,
              borderColor: '#66666654',
              borderWidth: "0.8",
            }
          };
        }

        var trendOverFrontEndJUnit = {
          name: 'trendOverFrontEndJUnit',
          title: 'Trend over front end JUnit',
          type: 'line',
          tooltipText: widgetHoverText.trendOverFrontEndJUnit,
          data: graphData,
          startDate: response.startDate,
          endDate: response.endDate
        };

        ctrl.trendOverFrontEndJUnit = trendOverFrontEndJUnit;
        ctrl.trendOverChartModal();
        return trendOverFrontEndJUnit;
      });
    };

    ctrl.fetchTrendOverSprintPredictability = function () {
      var route = '/api/trend/sprintPredictability?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.sendWidgetDetails(route, ctrl.paramSprintList || []).then(function (response) {
        var graphData;
        if (response && response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            options: {
              elements: {
                point: {
                  radius: 1.3,
                  hoverRadius: 1.3
                }
              },
              maintainAspectRatio: false,
              tooltips: {
                enabled: true
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    fontSize: 10,
                    callback: function (label, index, labels) {
                      if (response.unit === '%') {
                        return parseFloat(Math.round(label * 100) / 100) + (response.unit || '')
                      } else {
                        return parseFloat(Math.round(label * 100) / 100).toFixed(2) + (response.unit || '')
                      }
                    }
                  },
                  scaleLabel: {
                    display: true,
                    labelString: 'value in' + (response.unit || '')
                  },
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 10,
                    autoSkip: false
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: ctrl.secondColumnBgColor,
              borderColor: '#66666654',
              borderWidth: "0.8",
            }
          };
        }

        var trendOverSprintPredictability = {
          name: 'trendOverSprintPredictability',
          title: 'Trend over sprint predictability',
          type: 'line',
          tooltipText: widgetHoverText.trendOverSprintPredictability,
          data: graphData,
          fromSprint: response && response.fromSprint || '',
          toSprint: response && response.toSprint || ''
        };

        ctrl.trendOverSprintPredictability = trendOverSprintPredictability;
        ctrl.trendOverChartModal();
      });
    };

    ctrl.fetchTrendOverCommitmentReliability = function () {
      var route = '/api/trend/commitmentReliability?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.sendWidgetDetails(route, ctrl.paramSprintList || []).then(function (response) {
        var graphData;
        if (response && response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            options: {
              maintainAspectRatio: false,
              tooltips: {
                enabled: true
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    fontSize: 10,
                    callback: function (label, index, labels) {
                      if (response.unit === '%') {
                        return parseFloat(Math.round(label * 100) / 100) + (response.unit || '')
                      } else {
                        return parseFloat(Math.round(label * 100) / 100).toFixed(2) + (response.unit || '')
                      }
                    }
                  },
                  scaleLabel: {
                    display: true,
                    labelString: 'value in' + (response.unit || '')
                  },
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 10,
                    autoSkip: false
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: ctrl.secondColumnBgColor,
              borderColor: '#66666654',
              borderWidth: "0.8",
            }
          };
        }

        var trendOverCommitmentReliability = {
          name: 'trendOverCommitmentReliability',
          title: 'Trend over Commitment Reliability',
          type: 'line',
          tooltipText: widgetHoverText.trendOverCommitmentReliability,
          data: graphData,
          fromSprint: response && response.fromSprint || '',
          toSprint: response && response.toSprint || ''
        };

        ctrl.trendOverCommitmentReliability = trendOverCommitmentReliability;
        ctrl.trendOverChartModal();
      });
    };
    ctrl.fetchDefects = function () {
      var route = '/api/jiraMVP/defectCount';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        var graphData;
        if (response && response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            options: {
              maintainAspectRatio: false,
              tooltips: {
                enabled: true,
                fontSize: 3
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    beginAtZero: true,
                    fontSize: 8
                  }
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 8
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: ctrl.thirdColumnBgColor,
              borderColor: '#66666654',
              borderWidth: "0.8",
            }
          };
        }
        return {
          name: 'defectCount',
          title: 'Incidents/Defects',
          type: 'bar',
          tooltipText: widgetHoverText.defectCount,
          data: graphData
        };
      });
    };

    ctrl.fetchStoryLeadTimeToRelease = function () {
      var route = '/api/jiraMVP/DorToLive';
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        return {
          name: 'timeToRelease',
          title: 'Definition of Ready (DoR) to Live',
          type: 'text',
          tooltipText: widgetHoverText.storyLeadTime,
          data: (response.timeToRelease && response.timeToRelease.value) ? response.timeToRelease : null
        };
      });
    };

    ctrl.fetchTrendOverStoryLeadTime = function () {
      var route = '/api/trend/dorToDod?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.sendWidgetDetails(route, ctrl.paramSprintList || []).then(function (response) {
        var graphData;
        if (response && response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            options: {
              maintainAspectRatio: false,
              tooltips: {
                enabled: true
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    fontSize: 10,
                    callback: function (label, index, labels) {
                      if (response.unit === '%') {
                        return parseFloat(Math.round(label * 100) / 100) + (response.unit || '')
                      } else {
                        return parseFloat(Math.round(label * 100) / 100) + (response.unit || '')
                      }
                    }
                  },
                  scaleLabel: {
                    display: true,
                    labelString: 'value in' + (response.unit || '')
                  },
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 10,
                    autoSkip: false
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: ctrl.secondColumnBgColor,
              borderColor: '#66666654',
              borderWidth: "0.8",
            }
          };
        }

        var trendOverStoryLeadTime = {
          name: 'trendOverStoryLeadTime',
          title: 'Trend over Story Lead Time',
          type: 'line',
          tooltipText: widgetHoverText.trendOverStoryLeadTime,
          data: graphData,
          fromSprint: response && response.fromSprint || '',
          toSprint: response && response.toSprint || ''
        };

        ctrl.trendOverStoryLeadTime = trendOverStoryLeadTime;
        ctrl.trendOverChartModal();
      });
    };

    ctrl.fetchTrendOverStoryLiveLeadTime = function () {
      var route = '/api/trend/dodToLive?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.sendWidgetDetails(route, ctrl.paramSprintList || []).then(function (response) {
        var graphData;
        if (response && response.data && response.data.length) {
          graphData = {
            data: response.data,
            labels: response.labels,
            options: {
              maintainAspectRatio: false,
              tooltips: {
                enabled: true
              },
              scales: {
                yAxes: [{
                  id: 'y-axis',
                  type: 'linear',
                  display: true,
                  position: 'left',
                  ticks: {
                    fontSize: 10,
                    callback: function (label, index, labels) {
                      if (response.unit === '%') {
                        return parseFloat(Math.round(label * 100) / 100) + (response.unit || '')
                      } else {
                        return parseFloat(Math.round(label * 100) / 100) + (response.unit || '')
                      }
                    }
                  },
                  scaleLabel: {
                    display: true,
                    labelString: 'value in' + (response.unit || '')
                  },
                }],
                xAxes: [{
                  id: 'x-axis',
                  display: true,
                  ticks: {
                    fontSize: 10,
                    autoSkip: false
                  },
                  gridLines: {
                    display: false
                  }
                }]
              }
            },
            datasetOverride: {
              backgroundColor: ctrl.secondColumnBgColor,
              borderColor: '#66666654',
              borderWidth: "0.8",
            }
          };
        }

        var trendOverStoryLiveLeadTime = {
          name: 'trendOverStoryLiveLeadTime',
          title: 'Trend over Story Live Lead Time',
          type: 'line',
          tooltipText: widgetHoverText.trendOverStoryLiveLeadTime,
          data: graphData,
          fromSprint: response && response.fromSprint || '',
          toSprint: response && response.toSprint || ''
        };

        ctrl.trendOverStoryLiveLeadTime = trendOverStoryLiveLeadTime;
        ctrl.trendOverChartModal();
      });
    };

    ctrl.fetchAllSprintList = function () {
      var route = '/api/jiraMVP/sprintsList?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        ctrl.allSprintList = response || []
        ctrl.fromSprintList = response || []
        ctrl.toSprintList = response || []
      });
    };

    ctrl.fetchAllSprintListWithoutStatus = function () {
      var route = '/api/jiraMVP/sprintsListWithoutStatus?dashboardId=' + window.dashboardGlobalData.id;
      return customDashboardData.fetchWidgetDetails(route)
      .then(function (response) {
        ctrl.allSprintList = response || []
        ctrl.fromSprintList = response || []
        ctrl.toSprintList = response || []
      });
    };

    $scope.$watch('$root.logoImage', function () {
      ctrl.logoImage = $rootScope.logoImage || localStorage.getItem('logoImage');
    });

    pageLoad();
  }
})();